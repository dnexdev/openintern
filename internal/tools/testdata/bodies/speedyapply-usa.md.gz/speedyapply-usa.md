# 2027 Software Engineering Internship & New Grad Positions

This repository is a comprehensive list of Software Engineering jobs for college students in search of **internships** or **new graduate** positions. The positions are updated daily, and we prioritize jobs posted within the last 120 days.

### USA Positions :eagle:
- [Internships :books:](/) - **1025** available ([FAANG+](#faang), [Quant](#quant), [Other](#other))
- [New Graduate :mortar_board:](/NEW_GRAD_USA.md) - **1214** available ([FAANG+](/NEW_GRAD_USA.md#faang), [Quant](/NEW_GRAD_USA.md#quant), [Other](/NEW_GRAD_USA.md#other))

### International Positions :globe_with_meridians:
- [Internships :books:](/INTERN_INTL.md) - **814** available ([FAANG+](/INTERN_INTL.md#faang), [Quant](/INTERN_INTL.md#quant), [Other](/INTERN_INTL.md#other))
- [New Graduate :mortar_board:](/NEW_GRAD_INTL.md) - **1245** available ([FAANG+](/NEW_GRAD_INTL.md#faang), [Quant](/NEW_GRAD_INTL.md#quant), [Other](/NEW_GRAD_INTL.md#other))

<br/>
<div align="center">
  <a href="https://speedyapply.com">
    <img src="https://speedyapply.com/api/jobs/chart" width="800" alt="Software Engineering College Job Market">
  </a>
</div>
<div align="center">
  <a href="https://discord.gg/gaJnCmTHuN">
    <img src="https://github.com/user-attachments/assets/1547dbd1-89d9-4f14-8feb-70cab53b1335" width="132" alt="SpeedyApply Discord Server">
  </a>
  <a href="https://chromewebstore.google.com/detail/speedyapply-job-applicati/mbgjopdedgonlbpikjfibkccpmhjbnag">
    <img src="https://github.com/user-attachments/assets/e8ad0070-9f04-4b1c-9291-a268775aab69" width="132" alt="SpeedyApply Chrome Web Store">
  </a>
</div>
<br/>

:raised_hands: Looking for an **Artificial Intelligence** job? [Check out our AI/ML college jobs list.](https://github.com/speedyapply/2027-AI-College-Jobs) :raised_hands:

<a name="intern-usa"></a>
## 2027 USA SWE Internships :books::eagle:

[:arrow_down_small:End of List](#bottom)
<a name="top"></a>

### FAANG+

<!-- TABLE_FAANG_START -->
| Company | Position | Location | Salary | Posting | Age |
|---|---|---|---|---|---|
| <a href="https://www.nvidia.com"><strong>NVIDIA</strong></a> | Compiler Software Engineering Intern - Summer 2027 | Redmond, WA | $62/hr | <a href="https://nvidia.wd5.myworkdayjobs.com/en-US/nvidiaexternalcareersite/job/US-WA-Redmond/Compiler-Software-Engineering-Intern---Summer-2027_JR2028607"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 1d |
| <a href="https://www.nvidia.com"><strong>NVIDIA</strong></a> | Developer Technology Intern - AI - Summer 2027 | Santa Clara, CA | $62/hr | <a href="https://nvidia.wd5.myworkdayjobs.com/en-US/nvidiaexternalcareersite/job/US-CA-Santa-Clara/Developer-Technology-Intern--AI---Summer-2027_JR2030178"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 2d |
| <a href="https://www.nvidia.com"><strong>NVIDIA</strong></a> | Software Engineering Intern - Simulation Technology - Summer 2027 | Santa Clara, CA | $62/hr | <a href="https://nvidia.wd5.myworkdayjobs.com/en-US/nvidiaexternalcareersite/job/US-CA-Santa-Clara/Software-Engineering-Intern--Simulation-Technology---Summer-2027_JR2029531"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 2d |
| <a href="https://careers.rivian.com"><strong>Rivian</strong></a> | Software Engineering Intern - AI Platform - Autonomy - Summer 2027 | Palo Alto, CA | $51/hr | <a href="https://us-careers-rivian.icims.com/jobs/37339/job"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 6d |
| <a href="https://www.airbnb.com/"><strong>Airbnb</strong></a> | Software Engineering Intern - BS/MS | San Francisco, CA | $49/hr | <a href="https://careers.airbnb.com/positions/8360478?gh_jid=8360478"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 8d |
| <a href="https://www.amazon.com"><strong>Amazon</strong></a> | Software Development Engineer Intern - Artificial General Intelligence - Summer 2027 | Sunnyvale, CA | $53/hr | <a href="https://www.amazon.jobs/jobs/10606968/apply"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 15d |
| <a href="https://about.meta.com"><strong>Meta</strong></a> | Research Intern — Neural Network Training and Hardware-Software Co-Design | Burlingame, CA | $50/hr | <a href="https://www.metacareers.com/jobs/1560905132724186"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 16d |
| <a href="https://www.tiktok.com"><strong>TikTok</strong></a> | Client Security & Data Foundation Software Engineer - Intern - TikTok BRIC - 2027 Start | San Jose, CA | $60/hr | <a href="https://lifeattiktok.com/search/7705023349533346101"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 20d |
| <a href="https://www.tiktok.com"><strong>TikTok</strong></a> | Agentic AI Decision Platform Software Engineer - Intern - TikTok BRIC - 2027 Start - PhD | San Jose, CA | $60/hr | <a href="https://lifeattiktok.com/search/7705012688944810245"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 20d |
| <a href="https://www.amazon.com"><strong>Amazon</strong></a> | Front-End Engineer Internship - 2027 - US | Seattle, WA | $53/hr | <a href="https://www.amazon.jobs/jobs/10609992/apply"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 21d |
| <a href="https://www.microsoft.com"><strong>Microsoft</strong></a> | Software Engineer: Security & Identity Intern Opportunities for University Students - Redmond | Redmond, WA | $52/hr | <a href="https://apply.careers.microsoft.com/careers/job/1970393556922930"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 21d |
| <a href="https://www.microsoft.com"><strong>Microsoft</strong></a> | Research Intern - Research in Software Engineering - ML Systems - Agents | Redmond, WA | $52/hr | <a href="https://apply.careers.microsoft.com/careers/job/1970393557054069"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 21d |
| <a href="https://www.tiktok.com"><strong>TikTok</strong></a> | Software Engineer - Intern - TikTok Search - 2027 Start | San Jose, CA | $60/hr | <a href="https://lifeattiktok.com/search/7704696088079010053"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 21d |
| <a href="https://www.figma.com"><strong>Figma</strong></a> | PhD Intern - Software Engineer - Interaction Design - 2027 | San Francisco, CA +1 | $60/hr | <a href="https://boards.greenhouse.io/figma/jobs/6241542004?gh_jid=6241542004"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 22d |
| <a href="https://www.microsoft.com"><strong>Microsoft</strong></a> | Software Engineer - Teamwork Experiences Internship Opportunities | Redmond, WA | $52/hr | <a href="https://apply.careers.microsoft.com/careers/job/1970393557037859"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 23d |
| <a href="https://about.meta.com"><strong>Meta</strong></a> | Research Intern - Embedded AI on Wearables - PhD | Redmond, WA | $50/hr | <a href="https://www.metacareers.com/jobs/4070678619908522"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 31d |
| <a href="https://www.amazon.com"><strong>Amazon</strong></a> | Software Development Engineer Intern - Amazon Leo - Summer 2027 - USA | Redmond, WA | $53/hr | <a href="https://www.amazon.jobs/jobs/10587999/apply"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 34d |
| <a href="https://careers.rivian.com"><strong>Rivian</strong></a> | Software Engineering Intern - Embedded Platforms - Summer 2027 | Palo Alto, CA +2 | $51/hr | <a href="https://jobs.ashbyhq.com/rivianvw.tech/30c3af69-2dfc-4224-9abc-b2d9c0c41048"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 34d |
| <a href="https://careers.rivian.com"><strong>Rivian</strong></a> | Software Engineering Intern - Applications - Summer 2027 | Palo Alto, CA +1 | $51/hr | <a href="https://jobs.ashbyhq.com/rivianvw.tech/7cc3dd48-631f-45ec-ae95-46c7cf05b160"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 34d |
| <a href="https://careers.rivian.com"><strong>Rivian</strong></a> | Software Engineering Intern - Connected Systems - Summer 2027 | Palo Alto, CA +1 | $51/hr | <a href="https://jobs.ashbyhq.com/rivianvw.tech/62e45b20-cbdc-4d16-9466-00bc158b7a7f"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 34d |
| <a href="https://careers.rivian.com"><strong>Rivian</strong></a> | Software Engineering Intern - Vehicle Controls - Summer 2027 | Palo Alto, CA +1 | $51/hr | <a href="https://jobs.ashbyhq.com/rivianvw.tech/cb3559f0-2514-45f1-8d36-a11fa1dded0c"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 34d |
| <a href="https://www.microsoft.com"><strong>Microsoft</strong></a> | Software Engineer: Security & Identity Intern Opportunities for University Students - Cambridge | Cambridge, MA | $52/hr | <a href="https://apply.careers.microsoft.com/careers/job/1970393557044765"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 35d |
| <a href="https://www.twitch.tv"><strong>Twitch</strong></a> | Undergrad Software Engineering Intern - Grad Year: Winter 2027 | San Francisco, CA | $61/hr | <a href="https://job-boards.greenhouse.io/twitch/jobs/8886605002"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 35d |
| <a href="https://www.twitch.tv"><strong>Twitch</strong></a> | Undergrad Software Engineering Intern - Grad Year: Spring 2028 | San Francisco, CA | $61/hr | <a href="https://job-boards.greenhouse.io/twitch/jobs/8886748002"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 35d |
| <a href="https://www.salesforce.com"><strong>Salesforce</strong></a> | Summer 2027 Intern - Software Engineer - Security/Government | California, USA +2 | $54/hr | <a href="https://salesforce.wd12.myworkdayjobs.com/en-US/external_career_site/job/California---San-Francisco/Summer-2027-Intern---Software-Engineer--Security-Government-_JR364911-1"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 38d |
| <a href="https://www.microsoft.com"><strong>Microsoft</strong></a> | Research Intern - Efficient AI Software Systems | Redmond, WA | $52/hr | <a href="https://apply.careers.microsoft.com/careers/job/1970393557041731"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 41d |
| <a href="https://careers.rivian.com"><strong>Rivian</strong></a> | Software Engineering Intern - Machine Learning Research - Perception - Spring 2027 Co-Op | Palo Alto, CA | $51/hr | <a href="https://us-careers-rivian.icims.com/jobs/33801/job"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 42d |
| <a href="https://www.amazon.com"><strong>Amazon</strong></a> | Software Development Engineer Intern - Machine Learning/Automated Reasoning- Summer 2027 | Seattle, WA | $53/hr | <a href="https://www.amazon.jobs/jobs/10593521/apply"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 43d |
| <a href="https://www.figma.com"><strong>Figma</strong></a> | PhD Intern - Software Engineer - Graphics - 2027 | San Francisco, CA +1 | $60/hr | <a href="https://boards.greenhouse.io/figma/jobs/6219995004?gh_jid=6219995004"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 44d |
| <a href="https://netflix.com/"><strong>Netflix</strong></a> | Software Engineer Intern - Summer 2027 | Los Gatos, CA | $63/hr | <a href="https://explore.jobs.netflix.net/careers/job/790318904468"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 44d |

<!-- TABLE_FAANG_END -->

### Quant

<!-- TABLE_QUANT_START -->
| Company | Position | Location | Salary | Posting | Age |
|---|---|---|---|---|---|

<!-- TABLE_QUANT_END -->

### Other

<!-- TABLE_START -->
| Company | Position | Location | Posting | Age |
|---|---|---|---|---|
| <a href="https://www.coderabbit.ai/"><strong>CodeRabbit</strong></a> | Software Engineer - Intern | San Francisco, CA | <a href="https://jobs.ashbyhq.com/coderabbit/c30ab34a-98f3-4c41-b4ba-179bdbab32c9"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 0d |
| <a href="https://www.ixl.com"><strong>IXL Learning</strong></a> | Software Engineer - Intern | San Mateo, CA | <a href="https://www.ixl.com/company/jobs?gh_jid=8963039002"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 0d |
| <a href="https://www.apexspace.com/"><strong>Apex Technology</strong></a> | Flight Software Engineering Internship - Summer 2027 | Los Angeles, CA | <a href="https://jobs.ashbyhq.com/apex-technology-inc/744ea544-2601-4e58-8fac-94ea300653e3"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 1d |
| <a href="https://www.apexspace.com/"><strong>Apex Technology</strong></a> | Ground Software Engineering Internship - Spring or Summer 2027 | Los Angeles, CA | <a href="https://jobs.ashbyhq.com/apex-technology-inc/2d5ad921-241f-4e7a-b9ff-9d01763da88c"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 1d |
| <a href="https://www.apexspace.com/"><strong>Apex Technology</strong></a> | Software Engineering - Operating Systems Internship - Summer 2027 | Los Angeles, CA | <a href="https://jobs.ashbyhq.com/apex-technology-inc/3ce65300-2818-4601-9ee4-34a3c012d915"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 1d |
| <a href="https://www.apexspace.com/"><strong>Apex Technology</strong></a> | Software Engineering Internship - Test & Automation - Summer 2027 | Los Angeles, CA | <a href="https://jobs.ashbyhq.com/apex-technology-inc/692bb497-59ba-44df-bacf-fffd2f7c6344"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 1d |
| <a href="https://www.asml.com"><strong>ASML</strong></a> | Internship - Software Engineer | San Diego, CA | <a href="https://asml.wd3.myworkdayjobs.com/en-US/asmlext1/job/San-Diego-CA-USA/Internship---Software-Engineer_J-00357859"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 1d |
| <a href="https://www.asml.com"><strong>ASML</strong></a> | Internship-Timing and Energy Software | San Diego, CA | <a href="https://asml.wd3.myworkdayjobs.com/en-US/asmlext1/job/San-Diego-CA-USA/Internship-Timing-and-Energy-Software_J-00358478"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 1d |
| <a href="https://www.bandwidth.com"><strong>Bandwidth</strong></a> | Software Engineer Intern - Summer 2027 | Raleigh, NC | <a href="https://job-boards.greenhouse.io/bandwidth/jobs/8414426"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 1d |
| <a href="https://www.bandwidth.com"><strong>Bandwidth</strong></a> | Software Engineer Intern - Summer 2027 | Raleigh, NC | <a href="https://job-boards.greenhouse.io/bandwidth/jobs/8414436"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 1d |
| <a href="https://www.bandwidth.com"><strong>Bandwidth</strong></a> | Software Engineer Intern - Summer 2027 | Raleigh, NC | <a href="https://job-boards.greenhouse.io/bandwidth/jobs/8414440"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 1d |
| <a href="https://www.bandwidth.com"><strong>Bandwidth</strong></a> | Software Engineer Intern - Summer 2027 | Raleigh, NC | <a href="https://job-boards.greenhouse.io/bandwidth/jobs/8414444"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 1d |
| <a href="https://www.bandwidth.com"><strong>Bandwidth</strong></a> | Software Engineer Intern - Summer 2027 | Raleigh, NC | <a href="https://job-boards.greenhouse.io/bandwidth/jobs/8414430"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 1d |
| <a href="https://www.basepowercompany.com/"><strong>Base Power Company</strong></a> | Quantitative Developer Intern | Austin, TX | <a href="https://jobs.ashbyhq.com/base-power/b6b2332e-1226-4575-b2c9-9e5258f2540e"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 1d |
| <a href="http://www.bestegg.com/"><strong>Best Egg</strong></a> | Software Engineering Summer Intern | Wilmington, DE | <a href="https://jobs.lever.co/BestEgg/c29a9c21-d939-4a5a-82fd-4b1440d71392"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 1d |
| <a href="https://www.carrier.com"><strong>Carrier</strong></a> | Software & Controls Engineering Intern - Summer | Charlotte, NC | <a href="https://carrier.wd5.myworkdayjobs.com/en-US/jobs/job/CAN05-CCS-Charlotte-5900-Northwoods-Business-Parkway-Charlotte-NC-28269-USA/Software---Controls-Engineering-Intern---Summer_30222979"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 1d |
| <a href="https://meetdandy.com/"><strong>Dandy</strong></a> | Summer 2027 Internship - Software Engineering Intern | New York City, NY | <a href="https://jobs.ashbyhq.com/dandy/d43558e9-8e51-4980-b00d-39275063f099"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 1d |
| <a href="https://www.digital-control.com/"><strong>Digital Control</strong></a> | Software Engineering Intern | Kent, WA | <a href="https://apply.workable.com/digital-control/j/AB9A181560/"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 1d |
| <a href="https://www.kla.com"><strong>KLA</strong></a> | Software Engineering Intern | Ann Arbor, MI | <a href="https://kla.wd1.myworkdayjobs.com/en-US/ur/job/Ann-Arbor-MI/Software-Engineering-Intern_2641821-2"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 1d |
| <a href="https://lightmatter.co"><strong>Lightmatter</strong></a> | Firmware Intern - Summer 2027 | Boston, MA | <a href="https://boards.greenhouse.io/lightmatter/jobs/5492829008?gh_jid=5492829008"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 1d |
| <a href="https://www.ottoexcellence.com"><strong>Otto Engineering</strong></a> | Embedded Software Intern - Communications - Summer 2027 | Carpentersville, IL | <a href="https://otto-engineering-inc.breezy.hr/p/c0fdaec6842c-embedded-software-intern-communications-summer-2027"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 1d |
| <a href="https://sambanova.ai"><strong>SambaNova Systems</strong></a> | Cloud Platform Engineer Intern - San Jose | San Jose, CA | <a href="https://sambanova.ai/sambanova-available-positions/?gh_jid=6271352004"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 1d |
| <a href="https://www.signetjewelers.com"><strong>Signet Jewelers</strong></a> | Software Engineering Intern- Digital Commerce | Irving, TX | <a href="https://signetjewelers.wd1.myworkdayjobs.com/en-US/signetcorporatecareers/job/Support-Center---Irving-TX/Software-Engineering-Intern--Digital-Commerce_REQ_84709"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 1d |
| <a href="https://www.signetjewelers.com"><strong>Signet Jewelers</strong></a> | Software Engineering Intern- Digital Commerce | Irving, TX | <a href="https://signetjewelers.wd1.myworkdayjobs.com/en-US/signetcorporatecareers/job/Support-Center---Irving-TX/Software-Engineering-Intern--Digital-Commerce_REQ_84703"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 1d |
| <a href="https://statestreet.com"><strong>State Street</strong></a> | Software Engineering Intern - Full-time Internship - Jan - June 2027 | Boston, MA | <a href="https://statestreet.wd1.myworkdayjobs.com/en-US/global/job/Boston-Massachusetts/Software-Engineering-Intern---Full-time-Internship--Jan---June-2027-_R-801504"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 1d |
| <a href="https://www.t-mobile.com"><strong>T-Mobile</strong></a> | Summer 2027 Software Engineering Intern | Overland Park, KS | <a href="https://tmobile.wd1.myworkdayjobs.com/en-US/external/job/Overland-Park-Kansas/Summer-2027-Software-Engineering-Intern_REQ381315"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 1d |
| <a href="https://www.t-mobile.com"><strong>T-Mobile</strong></a> | Summer 2027 Software Engineer Internship | Overland Park, KS | <a href="https://tmobile.wd1.myworkdayjobs.com/en-US/external/job/Overland-Park-Kansas/Summer-2027-Software-Engineer-Internship_REQ381357"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 1d |
| <a href="https://www.t-mobile.com"><strong>T-Mobile</strong></a> | Summer 2027 Software Engineering Intern | Overland Park, KS +1 | <a href="https://tmobile.wd1.myworkdayjobs.com/en-US/external/job/Overland-Park-Kansas/Summer-2027-Software-Engineering-Intern_REQ381368"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 1d |
| <a href="https://www.waters.com"><strong>Waters</strong></a> | IT Intern - Software Development Platform Engineer | Milford, MA | <a href="https://uscareers-waters.icims.com/jobs/30388/2026-30388/job"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 1d |
| <a href="https://www.xonaspace.com/"><strong>Xona Space Systems</strong></a> | Software Engineering - Engineering Productivity Intern | Burlingame, CA | <a href="https://jobs.ashbyhq.com/xona-space/d3549244-52e2-4894-87f9-99fc8cbe26ab"><img src="https://i.imgur.com/JpkfjIq.png" alt="Apply" width="70"/></a> | 1d |

<!-- TABLE_END -->

<a name="bottom"></a>
[:arrow_up_small:Start of List](#top)
