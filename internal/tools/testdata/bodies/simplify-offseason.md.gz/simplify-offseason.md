# Off-Season Tech Internships by Pitt CSC & Simplify

We're back! Use this repo to share and keep track of software, tech, CS, PM, quant internships for **Fall 2026, Winter 2027, or Spring 2027**. The list is maintained collaboratively by the [Pitt Computer Science Club](https://pittcsc.org/) and [Simplify](https://simplify.jobs/)!

❗ Please note that this repository is exclusively for internships/co-ops in the United States, Canada, or Remote positions 🌎

🧠 For valuable tips on navigating the internship process, be sure to check out our guide [Zero to Offer](https://www.pittcs.wiki/zero-to-offer) 🧠.

🙏 **Contribute by submitting an [issue](https://github.com/SimplifyJobs/Summer2027-Internships/issues/new/choose)! See the contribution guidelines [here](./CONTRIBUTING.md)!** 🙏

---

### Browse 394 Internship Roles by Category

💻 **[Software Engineering](https://github.com/SimplifyJobs/Summer2027-Internships/blob/dev/README-Off-Season.md#-software-engineering-internship-roles)** (125)

📱 **[Product Management](https://github.com/SimplifyJobs/Summer2027-Internships/blob/dev/README-Off-Season.md#-product-management-internship-roles)** (25)

🤖 **[Data Science, AI & Machine Learning](https://github.com/SimplifyJobs/Summer2027-Internships/blob/dev/README-Off-Season.md#-data-science-ai--machine-learning-internship-roles)** (129)

📈 **[Quantitative Finance](https://github.com/SimplifyJobs/Summer2027-Internships/blob/dev/README-Off-Season.md#-quantitative-finance-internship-roles)** (11)

🔧 **[Hardware Engineering](https://github.com/SimplifyJobs/Summer2027-Internships/blob/dev/README-Off-Season.md#-hardware-engineering-internship-roles)** (104)

---

<div align="center">
	<p>
		<a href="https://simplify.jobs/?utm_source=pittcsc&utm_medium=internships_repo">
			<b>Applying to internships?</b>
			<br>
			Autofill all your applications in a single click.
			<br>
			<div>
				<a href="https://simplify.jobs/?utm_source=pittcsc&utm_medium=internships_repo">
          <img src="https://res.cloudinary.com/dpeo4xcnc/image/upload/v1636594918/simplify_pittcsc.png" width="450" alt="Simplify">
        </a>
			</div>
		</a>
		<sub><i>Stop manually re-entering your information. Simplify’s extension helps you autofill internship applications on millions of sites.</i></sub>
	</p>
</div>

## The List 🚴🏔


 - 🛂 - Does NOT offer Sponsorship
 - 🇺🇸 - Requires U.S. Citizenship
 - 🔒 - Internship application is closed

> **Note**:
> This README file is for **non-summer internships only**. For summer internships, please see the [Summer 2027 README](./README.md).

<!-- Please leave a one line gap between this and the table TABLE_START (DO NOT CHANGE THIS LINE) -->

---



## 💻 Software Engineering Internship Roles

[Back to top](#summer-2027-tech-internships-by-pitt-csc--simplify)

> 🔗 GitHub strips the code that makes links open in a new tab, so clicking a role here navigates away from the list. The [Simplify extension](https://simplify.jobs/install?utm_source=GHList&utm_medium=newtab) opens them in a new tab instead, so you keep your place.

<table>
<thead>
<tr>
<th>Company</th>
<th>Role</th>
<th>Location</th>
<th>Terms</th>
<th>Application</th>
<th>Age</th>
</tr>
</thead>
<tbody>
<tr>
<td><strong><a href="https://simplify.jobs/c/Exowatt?utm_source=GHList&utm_medium=company">Exowatt</a></strong></td>
<td>Software & AI Intern</td>
<td>Austin, TX</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://jobs.lever.co/exowatt/86589116-72a5-44f1-893a-1c688d15f2cf/apply?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/60fe2bfd-5d70-4125-a0fd-2ff792996d47?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>3d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Brave?utm_source=GHList&utm_medium=company">Brave</a></strong></td>
<td>Software Development Intern - Web3 Core</td>
<td>Remote in Canada</td>
<td>Winter 2026</td>
<td><div align="center"><a href="https://job-boards.greenhouse.io/brave/jobs/8412532?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/5051347d-3cdd-4c43-9290-d929b5f5ada6?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>3d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Oscar-Health?utm_source=GHList&utm_medium=company">Oscar Health</a></strong></td>
<td>Software Engineer Intern</td>
<td>NYC</td>
<td>Winter 2027, Spring 2028, Summer 2028, Winter 2028</td>
<td><div align="center"><a href="https://oscarhealth.com/careers/jobs?gh_jid=8407472&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/c9b6e057-a2e6-4569-82c2-9e595b27ae5b?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>3d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/AJ-Bell?utm_source=GHList&utm_medium=company">AJ Bell</a></strong></td>
<td>Digital Degree Apprentice - Software Development Pathway</td>
<td>Manchester, UK</td>
<td>Fall 2027</td>
<td><div align="center"><a href="https://jobs.smartrecruiters.com/AJBell1/744000163169494?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/55da762f-4d6d-4896-a252-592b49e94f26?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>3d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Milliman?utm_source=GHList&utm_medium=company">Milliman</a></strong></td>
<td>AI Product Engineer Intern</td>
<td>Brookfield, WI<br>Chicago, IL</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://recruiting2.ultipro.com/MIL1017/JobBoard/f54234e9-dfde-b183-fd20-4fbdb19cba7a/OpportunityDetail?opportunityId=4f353716-eb67-4f11-a274-efee2100be07&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/d8fa9795-d411-430a-b0a9-508801cbcd74?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>6d</td>
</tr>
<tr>
<td>↳</td>
<td>AI Product Engineer Intern</td>
<td>Brookfield, WI<br>Chicago, IL</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://recruiting2.ultipro.com/MIL1017/JobBoard/f54234e9-dfde-b183-fd20-4fbdb19cba7a/OpportunityDetail?opportunityId=d159c041-eb0e-4505-913f-aa006818d620&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/4592cc0c-9bc7-4dac-906c-98fd4fc8f71d?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>6d</td>
</tr>
<tr>
<td>🔥 <strong><a href="https://simplify.jobs/c/Tesla?utm_source=GHList&utm_medium=company">Tesla</a></strong></td>
<td>Software Engineer Intern - SI Hardware Architecture Simulation</td>
<td>Palo Alto, CA</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://www.tesla.com/careers/search/job/290756?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/9c50d6d5-ef29-435d-8941-7d083495ada7?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>6d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/MDA-Space?utm_source=GHList&utm_medium=company">MDA Space</a></strong></td>
<td>Engineering Student Intern - Python Test Data Processing</td>
<td>Sainte-Anne-de-Bellevue, QC, Canada</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://recruiting.ultipro.ca/MAC5000MCDW/JobBoard/664818ff-3594-4bec-9f30-3394e59e19f3/OpportunityDetail?opportunityId=67af442f-ca28-47b2-b86b-eaa3d5192fe0&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/284cb7c3-3b6e-4bc3-8271-c566bcd82aa2?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>6d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/AFL?utm_source=GHList&utm_medium=company">AFL</a></strong></td>
<td>Web Design/Development Intern</td>
<td>Duncan, SC</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://recruiting.ultipro.com/afl1002/JobBoard/d535bad2-e3ea-c8c8-2fb2-63621892e293/OpportunityDetail?opportunityId=6e9432db-e1de-4103-b8dd-5bfd57365e4d&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/9b4ba210-85a2-47f2-ac76-c01df9d9b748?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>6d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Flare-Io?utm_source=GHList&utm_medium=company">Flare</a></strong></td>
<td>Software Developer Intern</td>
<td>Montreal, QC, Canada</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://flare.bamboohr.com/careers/29/?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/ca3f8898-4242-437d-93c0-86e4161f061a?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>6d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/EUNA-Solutions?utm_source=GHList&utm_medium=company">EUNA Solutions</a></strong></td>
<td>Associate AI-Enablement Developer Co-op</td>
<td>Oakville, ON, Canada</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://euna.bamboohr.com/careers/822/?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/bf07fdd4-a43a-470b-afb8-5dde457d4650?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>7d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Uplinq?utm_source=GHList&utm_medium=company">Uplinq</a></strong></td>
<td>Software Engineer Intern - ASU</td>
<td>Scottsdale, AZ</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://ats.rippling.com/uplinq/jobs/db54b553-b172-4569-ac5f-933a5f8a8d8c?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/42bd2197-857c-4f16-9442-c07dc58c078a?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>7d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Cirrus-Logic?utm_source=GHList&utm_medium=company">Cirrus Logic</a></strong></td>
<td>Software Engineer AI/ML Intern 🎓</td>
<td>Austin, TX</td>
<td>Spring 2026</td>
<td><div align="center"><a href="https://jobs.eu.lever.co/cirrus/c5c67b95-e487-470b-97db-4c84e78e7f61/apply?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/0db792e0-4b7b-4be2-b4eb-3c1b4c22a7c8?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>8d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Truveta?utm_source=GHList&utm_medium=company">Truveta</a></strong></td>
<td>Software Engineer Intern</td>
<td>Seattle, WA</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://job-boards.greenhouse.io/truveta/jobs/6249810004?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/7766a454-005e-4e27-8359-8572fd17712f?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>8d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Kira-Learning?utm_source=GHList&utm_medium=company">Kira Learning</a></strong></td>
<td>Software Engineer Intern</td>
<td>SF</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://jobs.ashbyhq.com/kira/9d275e39-e62b-4ee6-9625-97a3ca6b88fe/application?embed=true&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/2f406251-cd61-4118-99af-c862671e6b0b?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>9d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/QSL?utm_source=GHList&utm_medium=company">QSL</a></strong></td>
<td>Software Development and Artificial Intelligence Intern</td>
<td>Québec City, QC, Canada</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://jobs.smartrecruiters.com/QSL/744000162086264?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/d9d37c94-a957-47d8-acce-351a80f126dc?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>9d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Angel-Host?utm_source=GHList&utm_medium=company">Angel Host</a></strong></td>
<td>AI Product Engineer Intern Co-op</td>
<td>Montreal, QC, Canada</td>
<td>Winter 2026, Winter 2027</td>
<td><div align="center"><a href="https://angelhost.bamboohr.com/careers/123/?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/77f0d4c4-57a5-49b8-81ed-085e150c6551?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>9d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/The-Opus-Group?utm_source=GHList&utm_medium=company">The Opus Group</a></strong></td>
<td>Interactive Resident</td>
<td>Remote in USA</td>
<td>Winter 2027, Spring 2027</td>
<td><div align="center"><a href="https://jobs.jobvite.com/theopusgroup/job/oPMUAfwP?nl=1&nl=1&fr=false&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/d174fe5d-9211-4aa0-9ec6-572bc4d1baa5?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>10d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Lumentum?utm_source=GHList&utm_medium=company">Lumentum</a></strong></td>
<td>AI Engineer Co-op Intern</td>
<td>Ottawa, ON, Canada</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://lumentum.wd5.myworkdayjobs.com/LITE/job/Canada---Ottawa-Bill-Leathem/AI-Engineer---Co-op-Intern_20261778?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/3e98015a-3194-46a5-968b-d11d119ab480?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>11d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Ciena?utm_source=GHList&utm_medium=company">Ciena</a></strong></td>
<td>Technical Solution Engineer Intern - SE&I</td>
<td>Montreal, QC, Canada<br>Ottawa, ON, Canada</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://ciena.wd5.myworkdayjobs.com/Careers/job/Ottawa/Technical-Solution-Engineer--Intern---SE-I_R032114?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/0e303eb4-b2a7-4b14-93a4-89b286202f08?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>14d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Canadian-Tire?utm_source=GHList&utm_medium=company">Canadian Tire</a></strong></td>
<td>Programmer Analyst Intern</td>
<td>Mississauga, ON, Canada</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://canadiantirecorporation.wd3.myworkdayjobs.com/Enterprise_External_Careers_Site/job/Mississauga-ON/Programmer-Analyst-Intern--12-months----Winter-2027_JR167748?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/a429667e-4913-40e2-8b6a-ff22e64696c8?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>14d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/TMX-Group?utm_source=GHList&utm_medium=company">TMX Group</a></strong></td>
<td>AI Engineer Intern</td>
<td>Toronto, ON, Canada</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://tmx.wd3.myworkdayjobs.com/TMX_Careers/job/Toronto---100-Adelaide-St-W/AI-Engineering-Intern_R-6680?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/94b49ba1-6d5b-4127-b0e4-d5d20509a4a9?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>15d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Jabil?utm_source=GHList&utm_medium=company">Jabil</a></strong></td>
<td>IT Programmer Analyst Intern Co-op</td>
<td>Florence, KY</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://jabil.wd5.myworkdayjobs.com/Jabil_Careers/job/Florence-KY/IT-Programmer-Analyst-Spring-Co-Op_J2471333?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/db4d59b7-dbd5-4991-bfef-36bf53423cca?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>15d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Parabola?utm_source=GHList&utm_medium=company">Parabola</a></strong></td>
<td>Engineer Intern</td>
<td>SF<br>NYC</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://jobs.ashbyhq.com/parabola-io/ec64d31c-ca7e-4633-b279-1589c53d7eb0/application?embed=true&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/9912194a-3526-43dc-9964-d2906b6b3a07?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>16d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Bose?utm_source=GHList&utm_medium=company">Bose</a></strong></td>
<td>Agentic AI Engineering Co-op - Active Noise Cancellation 🎓</td>
<td>Framingham, MA</td>
<td>Fall 2027</td>
<td><div align="center"><a href="https://boseallaboutme.wd503.myworkdayjobs.com/Bose_Careers/job/US-MA---Framingham/Agentic-AI-Engineering-Co-op---Active-Noise-Cancellation---Fall-2027_R29391?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/9098b7ca-d1bf-45b7-b333-102df783db3d?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>16d</td>
</tr>
</tbody>
</table>


<details>
<summary>🗃️ Inactive roles (1475)</summary>

<table>
<thead>
<tr>
<th>Company</th>
<th>Role</th>
<th>Location</th>
<th>Terms</th>
<th>Application</th>
<th>Age</th>
</tr>
</thead>
<tbody>
<tr>
<td><strong><a href="https://simplify.jobs/c/Mawer-Investment-Management?utm_source=GHList&utm_medium=company">Mawer Investment Management</a></strong></td>
<td>AI Orchestrator Student Intern</td>
<td>Calgary, AB, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>6d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Compunetix?utm_source=GHList&utm_medium=company">Compunetix</a></strong></td>
<td>Software Engineer Co-op</td>
<td>Monroeville, PA</td>
<td>Spring 2027</td>
<td>🔒</td>
<td>9d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Xradar?utm_source=GHList&utm_medium=company">Xradar</a></strong></td>
<td>Software Engineer Co-op</td>
<td>Burnaby, BC, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>9d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Manulife-Financial?utm_source=GHList&utm_medium=company">Manulife Financial</a></strong></td>
<td>Technology Enablement Analyst Co-op</td>
<td>Toronto, ON, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>10d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Altice-USA?utm_source=GHList&utm_medium=company">Altice USA</a></strong></td>
<td>Software Developer Intern</td>
<td>Bethpage, NY</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>10d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Manulife-Financial?utm_source=GHList&utm_medium=company">Manulife Financial</a></strong></td>
<td>Software Engineering Co-op Intern</td>
<td>Boston, MA</td>
<td>Spring 2027</td>
<td>🔒</td>
<td>14d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/BMO?utm_source=GHList&utm_medium=company">Bank of Montreal</a></strong></td>
<td>AI Developer Co-op Intern</td>
<td>Toronto, ON, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>15d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Altice-USA?utm_source=GHList&utm_medium=company">Altice USA</a></strong></td>
<td>Software Development Intern</td>
<td>Bethpage, NY</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>16d</td>
</tr>
<tr>
<td>↳</td>
<td>Developer Intern - Financial & People Systems</td>
<td>Bethpage, NY</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>16d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Royal-Bank-Of-Canada?utm_source=GHList&utm_medium=company">Royal Bank of Canada</a></strong></td>
<td>Global Investment Banking Intern</td>
<td>NYC</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>17d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Boston-Scientific?utm_source=GHList&utm_medium=company">Boston Scientific</a></strong></td>
<td>Urology R&D Software Engineering Co-op</td>
<td>Marlborough, MA<br>Maple Grove, MN</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>17d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Warner-Bros?utm_source=GHList&utm_medium=company">Warner Bros.</a></strong></td>
<td>Software Engineer Co-op</td>
<td>Needham, MA</td>
<td>Spring 2027</td>
<td>🔒</td>
<td>18d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Hootsuite?utm_source=GHList&utm_medium=company">Hootsuite</a></strong></td>
<td>Software Developer Co-op Intern</td>
<td>Toronto, ON, Canada<br>Vancouver, BC, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>20d</td>
</tr>
<tr>
<td>🔥 <strong><a href="https://simplify.jobs/c/Amazon?utm_source=GHList&utm_medium=company">Amazon</a></strong></td>
<td>Software Development Engineer Apprentice</td>
<td>Swansea, UK</td>
<td>Fall 2027</td>
<td>🔒</td>
<td>20d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/BMO?utm_source=GHList&utm_medium=company">Bank of Montreal</a></strong></td>
<td>Technology Research Associate Co-op Intern</td>
<td>Toronto, ON, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>21d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Boston-Scientific?utm_source=GHList&utm_medium=company">Boston Scientific</a></strong></td>
<td>Urology R&D Software Engineering Co-op</td>
<td>Marlborough, MA<br>Maple Grove, MN</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>22d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Royal-Bank-Of-Canada?utm_source=GHList&utm_medium=company">Royal Bank of Canada</a></strong></td>
<td>Quantitative Technology Services Co-op - Software Developer</td>
<td>Montreal, QC, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>22d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/BMO?utm_source=GHList&utm_medium=company">Bank of Montreal</a></strong></td>
<td>Machine Learning Developer Intern Co-op</td>
<td>Toronto, ON, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>22d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Wolters-Kluwer?utm_source=GHList&utm_medium=company">Wolters Kluwer</a></strong></td>
<td>Front-End Developer Intern - Se</td>
<td>Sherbrooke, QC, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>23d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Global-Relay?utm_source=GHList&utm_medium=company">Global Relay</a></strong></td>
<td>Java Developer Co-op</td>
<td>Halifax Regional Municipality, NS, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>23d</td>
</tr>
<tr>
<td>↳</td>
<td>Java Developer Co-op</td>
<td>Vancouver, BC, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>23d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Toshiba-Global-Commerce?utm_source=GHList&utm_medium=company">Toshiba Global Commerce Solutions</a></strong></td>
<td>AI Software Engineer Intern</td>
<td>Frisco, TX</td>
<td>Spring 2027</td>
<td>🔒</td>
<td>23d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Hearst?utm_source=GHList&utm_medium=company">Hearst</a></strong></td>
<td>Editorial AI Development Intern</td>
<td>SF</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>23d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Botpress-Technologies?utm_source=GHList&utm_medium=company">Botpress Technologies</a></strong></td>
<td>Software Development Intern</td>
<td>Montreal, QC, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>23d</td>
</tr>
<tr>
<td>↳</td>
<td>Software Developer Intern</td>
<td>Montreal, QC, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>23d</td>
</tr>
</tbody>
</table>


</details>



## 📱 Product Management Internship Roles

[Back to top](#summer-2027-tech-internships-by-pitt-csc--simplify)

> 📅 Curious when Big Tech product internships typically open? Simplify put together an [openings tracker](https://simplify.jobs/top-list/Associate-Product-Manager-Intern?utm_source=GHList&utm_medium=ot) based on historical data for those companies.

<table>
<thead>
<tr>
<th>Company</th>
<th>Role</th>
<th>Location</th>
<th>Terms</th>
<th>Application</th>
<th>Age</th>
</tr>
</thead>
<tbody>
<tr>
<td><strong><a href="https://simplify.jobs/c/Rubrik?utm_source=GHList&utm_medium=company">Rubrik</a></strong></td>
<td>Product Management Intern - Managed Service Provider 🎓</td>
<td>Palo Alto, CA</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://www.rubrik.com/company/careers/departments/job.8412766?gh_jid=8412766&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/f8f30537-c326-4d7f-9014-ada2b84211a0?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>2d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/JP-Morgan-Chase?utm_source=GHList&utm_medium=company">JP Morgan Chase</a></strong></td>
<td>Payments Intern</td>
<td>London, UK</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://jpmc.fa.oraclecloud.com/hcmUI/CandidateExperience/en/sites/CX_1001/job/210808799?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/6692aa48-6232-4d3f-ad18-2ac58fac07c0?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>9d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Altice-USA?utm_source=GHList&utm_medium=company">Altice USA</a></strong></td>
<td>Product Management Intern - Video CPE</td>
<td>Bethpage, NY</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://www.optimumcareers.com/job/Bethpage-Intern-Product-Management-Video-CPE-NY-11714/1449511700/?ats=successfactors&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/74b0f9c6-dbb2-4f07-9509-ca5e705fcde3?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>16d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/SharkNinja?utm_source=GHList&utm_medium=company">SharkNinja</a></strong></td>
<td>Product Test Engineering Co-op</td>
<td>Needham, MA</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://job-boards.greenhouse.io/sharkninjaoperatingllc/jobs/4726209006?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/4c145819-bb1c-4c66-835e-7b64fa52594a?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>16d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/BMO?utm_source=GHList&utm_medium=company">Bank of Montreal</a></strong></td>
<td>Treasury & Payment Solutions Strategy Intern</td>
<td>Toronto, ON, Canada</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://bmo.wd3.myworkdayjobs.com/Campus/job/Toronto-ON-CAN/Treasury---Payment-Solutions-Strategy-Internship--Summer-2027--4-months-_R260031382-1?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/b396261a-43b1-4768-afb9-f123bde8e362?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>17d</td>
</tr>
<tr>
<td>↳</td>
<td>Treasury & Payment Solutions Strategy Intern</td>
<td>Toronto, ON, Canada</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://bmo.wd3.myworkdayjobs.com/External/job/Toronto-ON-CAN/Treasury---Payment-Solutions-Strategy-Internship--Summer-2027--4-months-_R260031382?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/a6054289-fae5-465f-bd01-46f595652f77?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>17d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Equitable-Bank?utm_source=GHList&utm_medium=company">Equitable Bank</a></strong></td>
<td>Product Management Intern - Digital Banking</td>
<td>Toronto, ON, Canada</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://jobs.lever.co/eqbank/e4ed38f2-5de1-405f-a02d-c21f421bc7c1/apply?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/e214e212-97ea-403f-ac3f-a4dd07f8c2f2?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>22d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/SharkNinja?utm_source=GHList&utm_medium=company">SharkNinja</a></strong></td>
<td>Product Development Co-op</td>
<td>Needham, MA</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://job-boards.greenhouse.io/sharkninjaoperatingllc/jobs/4726452006?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/82f54e51-864a-4797-b7f5-d35f173af418?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>22d</td>
</tr>
<tr>
<td>🔥 <strong><a href="https://simplify.jobs/c/Tesla?utm_source=GHList&utm_medium=company">Tesla</a></strong></td>
<td>Product Management Intern - Product Management - Megapack Services 3</td>
<td>Palo Alto, CA</td>
<td>Winter 2027, Spring 2027</td>
<td><div align="center"><a href="https://www.tesla.com/careers/search/job/288805?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/300bff18-a855-45ba-a091-cac4b99a1e29?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>22d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Kabam?utm_source=GHList&utm_medium=company">Kabam</a></strong></td>
<td>Operations Product Manager Co-op</td>
<td>Vancouver, BC, Canada</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://jobs.lever.co/kabam/3c37f284-4ba4-4f74-93f7-d224b910e5c9/apply?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/8c4baab5-258d-462f-8da2-51acf9443ed9?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>23d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Axos-Bank?utm_source=GHList&utm_medium=company">Axos Bank</a></strong></td>
<td>Product Intern</td>
<td>San Diego, CA</td>
<td>Summer 2026, Spring 2026</td>
<td><div align="center"><a href="https://axos.wd5.myworkdayjobs.com/Axos/job/HQ---San-Diego-CA/Product-Intern_JR5662?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/20d77224-75db-40f6-a3fc-c685597f44c0?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>25d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/MANN-HUMMEL?utm_source=GHList&utm_medium=company">MANN+HUMMEL</a></strong></td>
<td>Product Management & Market Intelligence Intern</td>
<td>Gastonia, NC</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://careers.mann-hummel.com/job/Gastonia-Product-Management-&-Market-Intelligence-Intern-NC-28054/1453138533/?ats=successfactors&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/ccd783d4-b8da-44c9-93bd-529368e9b01c?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>27d</td>
</tr>
<tr>
<td>🔥 <strong><a href="https://simplify.jobs/c/TikTok?utm_source=GHList&utm_medium=company">TikTok</a></strong></td>
<td>Product Manager Project Intern - Global Monetization Product and Technology</td>
<td>San Jose, CA</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://lifeattiktok.com/search/7701486873210390837?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/742ca7bb-db0d-49b6-acf6-96f404388633?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>27d</td>
</tr>
<tr>
<td>↳</td>
<td>Product Manager Intern - Global Monetization Product and Technology</td>
<td>Seattle, WA</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://lifeattiktok.com/search/7701480558070597893?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/1cb17d04-00ff-475a-8d37-3a9a45606bf9?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>27d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Signify?utm_source=GHList&utm_medium=company">Signify</a></strong></td>
<td>Product Manager Intern</td>
<td>Aurora, CO</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://lighting.wd3.myworkdayjobs.com/jobs-and-careers/job/Aurora/Product-Management-Intern--Cooper-Lighting-Solutions---Spring-2027_366897?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/05dde452-e00b-4d52-bcf6-a81fc30f3ddb?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>28d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Signify?utm_source=GHList&utm_medium=company">Signify</a></strong></td>
<td>Product Management Intern</td>
<td>Peachtree City, GA</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://lighting.wd3.myworkdayjobs.com/jobs-and-careers/job/Peachtree-City/Product-Management-Intern--Cooper-Lighting-Solutions---Spring-2027_366870?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/ead75aa9-984d-4541-9ae4-b274528493c0?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>29d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/SOTI?utm_source=GHList&utm_medium=company">SOTI</a></strong></td>
<td>Associate Product Manager Intern</td>
<td>Mississauga, ON, Canada</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://soti.wd3.myworkdayjobs.com/SOTI-Next-Gen/job/Mississauga-Canada--Meadowvale-Office-HQ/Associate-Product-Manager-Intern--May-2027---12-Months-_R10638?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/c0597cd9-98b8-4c2b-9095-fb705a7fed10?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>1mo</td>
</tr>
<tr>
<td>🔥 <strong><a href="https://simplify.jobs/c/Tesla?utm_source=GHList&utm_medium=company">Tesla</a></strong></td>
<td>Internship - Product Management - Megapack Services - Winter/Spring 2027</td>
<td>Fremont, CA</td>
<td>Winter 2027, Spring 2027</td>
<td><div align="center"><a href="https://www.tesla.com/careers/search/job/287443?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/2dbc03af-2902-4227-a4b0-8d43c8b04b20?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/FanDuel?utm_source=GHList&utm_medium=company">FanDuel</a></strong></td>
<td>Product Co-op</td>
<td>Toronto, ON, Canada</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://boards.greenhouse.io/embed/job_app?token=8285180&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/8bad299b-1228-41e1-92f9-d56c2e26c840?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>1mo</td>
</tr>
<tr>
<td>🔥 <strong><a href="https://simplify.jobs/c/NVIDIA?utm_source=GHList&utm_medium=company">NVIDIA</a></strong></td>
<td>Product Management MBA Intern 🎓</td>
<td>Santa Clara, CA</td>
<td>Winter 2027, Summer 2028</td>
<td><div align="center"><a href="https://nvidia.wd5.myworkdayjobs.com/NVIDIAExternalCareerSite/job/US-CA-Santa-Clara/Product-Management-MBA-Intern--Laptop---Summer-2027_JR2025905?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/15f8d0bb-869f-465a-adb5-e585b4a54017?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Carlisle-Companies?utm_source=GHList&utm_medium=company">Carlisle Companies</a></strong></td>
<td>Product Management Intern</td>
<td>Carlisle, PA</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://jobs.smartrecruiters.com/Carlisle/3743990016055226?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/329b5bff-a33f-46ae-9f10-d6cf4c68b8cd?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Watts-Water?utm_source=GHList&utm_medium=company">Watts Water</a></strong></td>
<td>Product Management Co-op</td>
<td>Menomonee Falls, WI</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://wattswater.wd5.myworkdayjobs.com/Intern-External/job/Menomonee-Falls-WI/Product-Management-Co-op--Jan-June-2027_10017702?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/168c78d4-794a-45ac-8bfa-f51ece09f018?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/IDeaS?utm_source=GHList&utm_medium=company">IDeaS</a></strong></td>
<td>Product Management Intern</td>
<td>Bloomington, MN</td>
<td>Winter 2026</td>
<td><div align="center"><a href="https://ideas-sas.icims.com/jobs/42648/job?mobile=true&needsRedirect=false&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/4200fef6-f177-438c-aaf7-eb7c087f048b?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/L3Harris-Technologies?utm_source=GHList&utm_medium=company">L3Harris Technologies</a></strong></td>
<td>Product Management Intern</td>
<td>Rochester, NY</td>
<td>Winter 2026</td>
<td><div align="center"><a href="https://jobs.l3harris.com/job/Rochester-Product-Management-Intern-(Rochester,-NY)-NY-14610-1839/1433689700/?ats=successfactors&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/ba21bc92-2d44-433d-a0dc-0d5c254061c5?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>1mo</td>
</tr>
<tr>
<td>🔥 <strong><a href="https://simplify.jobs/c/Adobe?utm_source=GHList&utm_medium=company">Adobe</a></strong></td>
<td>MBA Intern - Product Manager 🎓</td>
<td>SF<br>San Jose, CA</td>
<td>Winter 2026</td>
<td><div align="center"><a href="https://adobe.wd5.myworkdayjobs.com/external_experienced/job/San-Jose/XMLNAME-2027-MBA-Intern---Product-Manager_R172261?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/442e767f-02ce-411c-8238-a1f8c5d06757?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>1mo</td>
</tr>
</tbody>
</table>


<details>
<summary>🗃️ Inactive roles (245)</summary>

<table>
<thead>
<tr>
<th>Company</th>
<th>Role</th>
<th>Location</th>
<th>Terms</th>
<th>Application</th>
<th>Age</th>
</tr>
</thead>
<tbody>
<tr>
<td><strong><a href="https://simplify.jobs/c/Warner-Bros?utm_source=GHList&utm_medium=company">Warner Bros.</a></strong></td>
<td>Product Management Co-op</td>
<td>Needham, MA</td>
<td>Spring 2027</td>
<td>🔒</td>
<td>18d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Boston-Scientific?utm_source=GHList&utm_medium=company">Boston Scientific</a></strong></td>
<td>R&D Product Development Intern</td>
<td>Montreal, QC, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>22d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/SharkNinja?utm_source=GHList&utm_medium=company">SharkNinja</a></strong></td>
<td>Product Strategy & Development Co-op</td>
<td>Needham, MA</td>
<td>Spring 2027</td>
<td>🔒</td>
<td>29d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Autodesk?utm_source=GHList&utm_medium=company">Autodesk</a></strong></td>
<td>Product Manager Intern - Manufacturing</td>
<td>Toronto, ON, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/1Password?utm_source=GHList&utm_medium=company">1Password</a></strong></td>
<td>Product Management Intern - End User Experience</td>
<td>Remote in USA<br>Remote in Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/TD-Bank?utm_source=GHList&utm_medium=company">TD Bank</a></strong></td>
<td>Life & Health Product Management Co-op Intern</td>
<td>Toronto, ON, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/MLSE?utm_source=GHList&utm_medium=company">Maple Leaf Sports & Entertainment Partnership (MLSE)</a></strong></td>
<td>Business Strategy & Product Management Intern - AI</td>
<td>Toronto, ON, Canada</td>
<td>Winter 2026</td>
<td>🔒</td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/CIBC?utm_source=GHList&utm_medium=company">CIBC</a></strong></td>
<td>Product Analyst Co-op</td>
<td>Toronto, ON, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Behaviour-Interactive?utm_source=GHList&utm_medium=company">Behaviour Interactive</a></strong></td>
<td>Product Management Intern - 7 Days to Die</td>
<td>Montreal, QC, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Interac?utm_source=GHList&utm_medium=company">Interac</a></strong></td>
<td>Product Intern - Money Movement</td>
<td>Toronto, ON, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Interac?utm_source=GHList&utm_medium=company">Interac</a></strong></td>
<td>Payments Product Intern</td>
<td>Toronto, ON, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Manulife-Financial?utm_source=GHList&utm_medium=company">Manulife Financial</a></strong></td>
<td>Pharmacy Operations Co-op</td>
<td>Waterloo, ON, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Canadian-Tire?utm_source=GHList&utm_medium=company">Canadian Tire</a></strong></td>
<td>Product Strategy Student Intern</td>
<td>Oakville, ON, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Bosch?utm_source=GHList&utm_medium=company">Robert Bosch Venture Capital</a></strong></td>
<td>Product Management Co-op</td>
<td>Fountain Inn, SC</td>
<td>Spring 2027</td>
<td>🔒</td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/KnowBe4?utm_source=GHList&utm_medium=company">KnowBe4</a></strong></td>
<td>Associate Product Manager Intern</td>
<td>Clearwater, FL</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/RSM?utm_source=GHList&utm_medium=company">RSM</a></strong></td>
<td>Catamaran Managed Services Intern</td>
<td>SF</td>
<td>Fall 2026</td>
<td>🔒</td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/OptionsClearingCorporation?utm_source=GHList&utm_medium=company">OCC</a></strong></td>
<td>Strategy Intern</td>
<td>Chicago, IL</td>
<td>Summer 2026, Fall 2026</td>
<td>🔒</td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Attentive?utm_source=GHList&utm_medium=company">Attentive</a></strong></td>
<td>Product Management Intern - Agentic Integrations</td>
<td>United States</td>
<td>Winter 2026</td>
<td>🔒</td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Autodesk?utm_source=GHList&utm_medium=company">Autodesk</a></strong></td>
<td>Product Management Intern</td>
<td>Toronto, ON, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>1mo</td>
</tr>
<tr>
<td>↳</td>
<td>Product Management Intern</td>
<td>Toronto, ON, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Epic-Games?utm_source=GHList&utm_medium=company">Epic Games</a></strong></td>
<td>Technical Product Management Intern</td>
<td>Cary, NC</td>
<td>Winter 2026</td>
<td>🔒</td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/American-Express?utm_source=GHList&utm_medium=company">American Express</a></strong></td>
<td>Product Analyst Intern - Undergraduate - ECMX</td>
<td>London, UK</td>
<td>Winter 2026</td>
<td>🔒</td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Rockwell-Automation?utm_source=GHList&utm_medium=company">Rockwell Automation</a></strong></td>
<td>Product Management Intern - Digital Client</td>
<td>Mequon, WI</td>
<td>Winter 2026</td>
<td>🔒</td>
<td>1mo</td>
</tr>
<tr>
<td>↳</td>
<td>Product Management Intern - Digital Client</td>
<td>Mequon, WI</td>
<td>Winter 2026</td>
<td>🔒</td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Altice-USA?utm_source=GHList&utm_medium=company">Altice USA</a></strong></td>
<td>Mobile Device Product Management Intern</td>
<td>Bethpage, NY</td>
<td>Winter 2026</td>
<td>🔒</td>
<td>1mo</td>
</tr>
</tbody>
</table>


</details>



## 🤖 Data Science, AI & Machine Learning Internship Roles

[Back to top](#summer-2027-tech-internships-by-pitt-csc--simplify)

> 📄 Here's the [resume template](https://docs.google.com/document/d/1azvJt51U2CbpvyO0ZkICqYFDhzdfGxU_lsPQTGhsn94/edit?usp=sharing) used by Stanford CS and Pitt CSC for internship prep.

> 🧠 Want to know what keywords your resume is missing for a job? Use the blue Simplify application link to instantly compare your resume to any job description.

<table>
<thead>
<tr>
<th>Company</th>
<th>Role</th>
<th>Location</th>
<th>Terms</th>
<th>Application</th>
<th>Age</th>
</tr>
</thead>
<tbody>
<tr>
<td><strong><a href="https://simplify.jobs/c/DEPT?utm_source=GHList&utm_medium=company">DEPT</a></strong></td>
<td>AI Engineer Trainee - AI Engineer Traineeship</td>
<td>Netherlands<br>United Kingdom</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://job-boards.greenhouse.io/dept/jobs/8414501?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/f22421d0-9ba8-49f6-9e0b-6e2c924538f0?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>0d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/QuEra-Computing?utm_source=GHList&utm_medium=company">QuEra Computing</a></strong></td>
<td>Photonics Data Engineer Intern - Data Management</td>
<td>Boston, MA</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://job-boards.greenhouse.io/queracomputinginc/jobs/5495029008?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/434aa7d8-8775-43bf-be81-a590f69d4ea5?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>1d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Tombras?utm_source=GHList&utm_medium=company">Tombras</a></strong></td>
<td>Data Science Intern</td>
<td>Knoxville, TN</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://ats.rippling.com/tombrascareers/jobs/fe7d5efc-78ca-4e57-8f46-2b9a1c9e8cf9?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/4ff3bb5b-6a65-4c87-8f15-ea7c0e10f354?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>1d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Noblis?utm_source=GHList&utm_medium=company">Noblis</a></strong></td>
<td>AI/ML Research Intern</td>
<td>United States</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://careers.noblis.org/jobs/28841?icims=1&lang=en-us&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/26ee6493-02d8-49da-a580-97b2be904636?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>1d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/The-Tech-Interactive?utm_source=GHList&utm_medium=company">The Tech Interactive</a></strong></td>
<td>STEM Impact & Data Reporting Intern</td>
<td>San Jose, CA</td>
<td>Winter 2027, Spring 2027</td>
<td><div align="center"><a href="https://ats.rippling.com/the-tech/jobs/1681a3cc-c0d0-4161-8fcc-6edac78f0475?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/98f1165f-bf4b-4417-bbc9-2922776a829d?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>2d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/City-Of-Campbell-River?utm_source=GHList&utm_medium=company">City of Campbell River</a></strong></td>
<td>OMS Project Co-op - Capital Projects</td>
<td>Campbell River, BC, Canada</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://jobs.smartrecruiters.com/CityOfCampbellRiver/744000163555848?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/663452b4-b060-4430-8058-dea460c7c787?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>2d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Red-Bull?utm_source=GHList&utm_medium=company">Red Bull</a></strong></td>
<td>Data Science Intern</td>
<td>Morristown, NJ</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://jobs.smartrecruiters.com/RedBull/744000163139699?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/c8721b3d-1bb7-4fc0-9c22-09f70904d771?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>3d</td>
</tr>
<tr>
<td>↳</td>
<td>RBII Team Analysis Intern</td>
<td>Morristown, NJ</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://jobs.smartrecruiters.com/RedBull/744000163139439?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/5a0d7972-1370-47d6-bacf-3777c937018d?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>3d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/GrayMatterRobotics?utm_source=GHList&utm_medium=company">GrayMatter Robotics</a></strong></td>
<td>Robotics Engineering Intern: Systems & Applications</td>
<td>Carson, CA</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://jobs.ashbyhq.com/graymatter-robotics/347cbb66-c542-4c41-bdfc-3f9fa242b20b/application?embed=true&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/542449da-e7d7-4289-a17e-c344f121c66a?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>4d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Kentucky-Science-And-Technology-Corporation?utm_source=GHList&utm_medium=company">Kentucky Science and Technology Corporation</a></strong></td>
<td>Data Management Intern</td>
<td>Lexington, KY<br>Kentucky</td>
<td>Winter 2026</td>
<td><div align="center"><a href="https://thekentuckyscienceandtechnologycorporation.applytojob.com/apply/ISJX57K0S9/Data-Management-Intern?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/15021bea-ce77-455e-8ecd-fd433aead168?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>5d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/MDA-Space?utm_source=GHList&utm_medium=company">MDA Space</a></strong></td>
<td>Engineering Student Co-op - AI/ML Specialist</td>
<td>Richmond, BC, Canada</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://recruiting.ultipro.ca/MAC5000MCDW/JobBoard/664818ff-3594-4bec-9f30-3394e59e19f3/OpportunityDetail?opportunityId=b5aef546-676b-4f7a-8c20-acfa8f25069f&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/b720bb1f-7ec3-4397-9391-d9af72d5315f?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>6d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/AFL?utm_source=GHList&utm_medium=company">AFL</a></strong></td>
<td>Business Intelligence Co-op</td>
<td>Duncan, SC</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://recruiting.ultipro.com/afl1002/JobBoard/d535bad2-e3ea-c8c8-2fb2-63621892e293/OpportunityDetail?opportunityId=33f4e729-d1f6-4137-a95a-4ac8b27a9453&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/4980de46-5cd9-441b-a730-90fda15b31b5?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>6d</td>
</tr>
</tbody>
</table>

---

<div align="center" id="github-cutoff-warning">
  <h2>🔗 See Full List</h2>
  <p><strong>⚠️ GitHub preview cuts off around here due to file size limits.</strong></p>
  <p>📋 <strong><a href="https://github.com/SimplifyJobs/Summer2027-Internships/blob/dev/README.md#-see-full-list">Click here to view the complete list with all internship opportunities!</a></strong> 📋</p>
  <p><em>To find even more internships in tech, check out <a href="https://simplify.jobs/jobs?category=Software%20Engineering%3BHardware%20Engineering%3BQuantitative%20Finance%3BProduct%20Management%3BData%20%26%20Analytics%3BIT%20%26%20Security&jobId=2ac81173-86b5-4dbd-a7a9-260847c259cc&jobType=Internship?utm_source=GHList">Simplify's website</a>.</em></p>
</div>

---

<table>
<thead>
<tr>
<th>Company</th>
<th>Role</th>
<th>Location</th>
<th>Application</th>
<th>Age</th>
</tr>
</thead>
<tbody>
<tr>
<td><strong><a href="https://simplify.jobs/c/Ottawa-Tourism?utm_source=GHList&utm_medium=company">Ottawa Tourism</a></strong></td>
<td>Business Intelligence Assistant Intern</td>
<td>Ottawa, ON, Canada</td>
<td>Winter 2026</td>
<td><div align="center"><a href="https://ottawatourism.bamboohr.com/careers/123/?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/a35f05d0-6904-476c-b09f-1474155144a0?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>6d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/EFI-Foundation?utm_source=GHList&utm_medium=company">EFI Foundation</a></strong></td>
<td>Research Intern/Fellow</td>
<td>Washington, DC</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://efifoundation.bamboohr.com/careers/43/?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/64e1919d-6c6d-43fa-a3ee-0f0579a5f5d2?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>6d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Mackenzie-Investments?utm_source=GHList&utm_medium=company">Mackenzie Investments</a></strong></td>
<td>AI Program Intern</td>
<td>Toronto, ON, Canada</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://careersen-mackenzieinvestments.icims.com/jobs/6446/job?mobile=true&needsRedirect=false&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/0f778216-9855-4109-a28c-04240cb2a6b7?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>7d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Smarty?utm_source=GHList&utm_medium=company">Smarty</a></strong></td>
<td>Data Acquisition & Quality Specialist Intern</td>
<td>Orem, UT</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://ats.rippling.com/smarty/jobs/9bdebab0-e5e9-49d3-b995-cdaa62796be6?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/fa2cd117-f8f4-4f40-bb10-fb0561ef0154?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>9d</td>
</tr>
<tr>
<td>🔥 <strong><a href="https://simplify.jobs/c/Meta?utm_source=GHList&utm_medium=company">Meta</a></strong></td>
<td>Visiting Researcher Intern - AI Mentorship Program 🎓</td>
<td>Montreal, QC, Canada</td>
<td>Fall 2027</td>
<td><div align="center"><a href="https://www.metacareers.com/jobs/1110284504699535?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/35b35e67-616d-4fb4-a15c-c0477b9c5670?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>9d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Falcomm?utm_source=GHList&utm_medium=company">Falcomm</a></strong></td>
<td>AI/ML Software Engineer Undergraduate Intern - AI/CAD Integration</td>
<td>Atlanta, GA</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://apply.workable.com/falcomm/j/64D0E86EFE/apply?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/f1e8f352-3cfb-4c29-aed1-c4c57d3bdb5d?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>9d</td>
</tr>
<tr>
<td>↳</td>
<td>AI/ML Software Engineer Graduate Intern - AI/CAD Integration</td>
<td>Atlanta, GA</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://apply.workable.com/falcomm/j/41F139E6F7/apply?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/d5a4e4de-19f7-4b33-af36-7e2512eefca5?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>9d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/New-York-City-Housing-Development-Corporation?utm_source=GHList&utm_medium=company">New York City Housing Development Corporation</a></strong></td>
<td>Strategic Operations Graduate Intern</td>
<td>NYC</td>
<td>Fall 2026</td>
<td><div align="center"><a href="https://jobs.jobvite.com/nychdc/job/o8D0Afw5?nl=1&nl=1&fr=false&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/fc9de8db-765c-468f-8afd-cd34f86332fe?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>9d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Exowatt?utm_source=GHList&utm_medium=company">Exowatt</a></strong></td>
<td>Robotics & Physical AI Intern</td>
<td>Miami, FL</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://jobs.lever.co/exowatt/ec23e694-6716-450d-bfbb-276ca8da3d1c/apply?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/f5c0fd6f-a358-4c5b-8523-ec698800634b?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>9d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/NorthStar-Earth-Space?utm_source=GHList&utm_medium=company">NorthStar Earth & Space</a></strong></td>
<td>Research Intern - AI for Earth Observation 🎓</td>
<td>Montreal, QC, Canada</td>
<td>Winter 2028</td>
<td><div align="center"><a href="https://northstarearthandspace.bamboohr.com/careers/117/?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/fb8c19af-6f4e-4bce-8ee3-4b265a51000f?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>9d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/OLG?utm_source=GHList&utm_medium=company">OLG</a></strong></td>
<td>Forensic Investigations Intern</td>
<td>Sault Ste. Marie, ON, Canada</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://olg.wd3.myworkdayjobs.com/Careers-Students/job/Sault-Ste-Marie-Ontario-Canada/Student---Forensic-Investigations_R26_00701?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/4ccf9764-a0d1-4496-ac93-21fe9ea38a0f?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>10d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/BioMerieux?utm_source=GHList&utm_medium=company">bioMérieux</a></strong></td>
<td>Machine Learning Co-op</td>
<td>Durham, NC</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://jobs.jobvite.com/biofiredx/job/ol94AfwS?nl=1&nl=1&fr=false&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/749a0e9d-85b5-41f9-a4c6-8ae33659d412?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>10d</td>
</tr>
<tr>
<td>🔥 <strong><a href="https://simplify.jobs/c/Meta?utm_source=GHList&utm_medium=company">Meta</a></strong></td>
<td>Visiting Researcher Intern - AI Mentorship Program 🎓</td>
<td><details><summary><strong>5 locations</strong></summary>Seattle, WA<br>SF<br>Menlo Park, CA<br>NYC<br>Bellevue, WA</details></td>
<td>Fall 2027</td>
<td><div align="center"><a href="https://www.metacareers.com/jobs/4529244430625751?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/2f47adc5-27b6-4476-85f7-6dff444004b3?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>10d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Noblis?utm_source=GHList&utm_medium=company">Noblis</a></strong></td>
<td>Environmental Analyst Intern</td>
<td>United States</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://careers.noblis.org/jobs/28139?icims=1&lang=en-us&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/62fb644f-b6de-4153-9491-e224722f5dc4?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>10d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Pfizer?utm_source=GHList&utm_medium=company">Pfizer</a></strong></td>
<td>Integrated Insights & Strategy Undergraduate Intern</td>
<td>Tadworth, UK</td>
<td>Fall 2027</td>
<td><div align="center"><a href="https://pfizer.wd1.myworkdayjobs.com/en-US/PfizerCareers/job/United-Kingdom---Walton-Oaks/Integrated-Insights---Strategy-Undergraduate_4967524?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/ec1da18f-202a-4664-af1c-3dc9e0593e7f?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>11d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/IPEX?utm_source=GHList&utm_medium=company">IPEX</a></strong></td>
<td>Manufacturing Excellence Co-op</td>
<td>Oakville, ON, Canada</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://aliaxis.wd3.myworkdayjobs.com/IPEX/job/CA---Oakville-3---Office/Manufacturing-Excellence-Co-Op-Student--Winter-2027---Etudiant-Coop-excellence-manufacturire--Hiver-2027_R-58664-1?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/44e4939c-ec3e-41da-9010-55ab672fc672?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>12d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Carnegie-Mellon-University?utm_source=GHList&utm_medium=company">Carnegie Mellon University</a></strong></td>
<td>Cyber AI Engineering Intern</td>
<td>Pittsburgh, PA</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://cmu.wd115.myworkdayjobs.com/cmu/job/Pittsburgh-PA/Cyber-AI-Engineering-Intern--Spring-2027-_2025346-1?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/aabe0127-a865-419b-ad95-ec112ec672e9?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>14d</td>
</tr>
<tr>
<td>🔥 <strong><a href="https://simplify.jobs/c/Adobe?utm_source=GHList&utm_medium=company">Adobe</a></strong></td>
<td>Research Scientist Intern 🎓</td>
<td>London, UK</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://adobe.wd5.myworkdayjobs.com/external_experienced/job/London/XMLNAME-2027-Intern---Research-Scientist_R173345?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/e97730e6-349e-4100-bc8c-7818046c2740?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>14d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Compassion-International?utm_source=GHList&utm_medium=company">Compassion International</a></strong></td>
<td>Creation Care GIS Analyst Intern</td>
<td>United States</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://compassion.wd5.myworkdayjobs.com/compassioncareers/job/USA---Global-Ministry-Center/GIS-Geospatial-Analyst-Intern_R8713-2?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/2aa0e77d-93f7-485a-8b82-0487eb24ac44?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>15d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/ChukMedia?utm_source=GHList&utm_medium=company">ChukMedia</a></strong></td>
<td>Data Analytics Resident</td>
<td>NYC</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://chukmedia.com/careers/?gh_jid=8191173&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/7d2a848f-d9c6-45db-a088-0907f39e6c61?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>15d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Ciena?utm_source=GHList&utm_medium=company">Ciena</a></strong></td>
<td>AI/ML Layout Engineering Intern 🎓</td>
<td>Ottawa, ON, Canada</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://ciena.wd5.myworkdayjobs.com/Careers/job/Ottawa/AI-ML-Layout-Engineering-Intern--Winter-2027-_R032102?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/99989330-4792-411f-8085-e5cbcfcd11b4?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>16d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Equipment-Share?utm_source=GHList&utm_medium=company">EquipmentShare</a></strong></td>
<td>Uptime Management Center Intern</td>
<td>Columbia, MO</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://www.equipmentshare.com/careers/openings/?gh_jid=8371863&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/3a397fee-4500-48e2-86cf-d5b0b00079d8?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>16d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Moss-Ag?utm_source=GHList&utm_medium=company">Moss</a></strong></td>
<td>Intern - Multiple Teams</td>
<td>SF</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://jobs.ashbyhq.com/mossrobotics/d16d9e47-fc07-4e49-95dc-6a997421114c/application?embed=true&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/4f60dc05-433a-4dca-a3fc-b606e679ccb7?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>20d</td>
</tr>
<tr>
<td>🔥 <strong><a href="https://simplify.jobs/c/Tesla?utm_source=GHList&utm_medium=company">Tesla</a></strong></td>
<td>Software Engineer Intern - SI Reinforcement Learning</td>
<td>Palo Alto, CA</td>
<td>Winter 2027, Spring 2027</td>
<td><div align="center"><a href="https://www.tesla.com/careers/search/job/289240?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/8c8362c9-f137-4db2-bae1-421d4b24b60c?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>20d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/SharkNinja?utm_source=GHList&utm_medium=company">SharkNinja</a></strong></td>
<td>Applied AI & Analytics Co-op</td>
<td>Miami, FL<br>Needham, MA<br>NYC</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://job-boards.greenhouse.io/sharkninjaoperatingllc/jobs/4725275006?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/2db81630-834e-4417-80c9-b873195cb9e0?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>20d</td>
</tr>
</tbody>
</table>


<details>
<summary>🗃️ Inactive roles (1892)</summary>

<table>
<thead>
<tr>
<th>Company</th>
<th>Role</th>
<th>Location</th>
<th>Terms</th>
<th>Application</th>
<th>Age</th>
</tr>
</thead>
<tbody>
<tr>
<td><strong><a href="https://simplify.jobs/c/Kinaxis?utm_source=GHList&utm_medium=company">Kinaxis</a></strong></td>
<td>Data Foundations Intern - Data & Analytics</td>
<td>Ottawa, ON, Canada<br>Remote in Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>3d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Mawer-Investment-Management?utm_source=GHList&utm_medium=company">Mawer Investment Management</a></strong></td>
<td>AI Engineer Student Intern</td>
<td>Calgary, AB, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>6d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/CMI-Media-Group?utm_source=GHList&utm_medium=company">CMI Media Group</a></strong></td>
<td>Business Insights Intern</td>
<td>Chicago, IL</td>
<td>Fall 2026</td>
<td>🔒</td>
<td>9d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Ross-Video?utm_source=GHList&utm_medium=company">Ross Video</a></strong></td>
<td>Research Assistant Co-op - AI Focus</td>
<td>Nepean, Ottawa, ON, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>9d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Altice-USA?utm_source=GHList&utm_medium=company">Altice USA</a></strong></td>
<td>Data Analyst Intern - Modernization Program BSS/OSS Migration</td>
<td>Bethpage, NY</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>10d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Seaspan?utm_source=GHList&utm_medium=company">Seaspan</a></strong></td>
<td>Data Engineering Intern</td>
<td>North Vancouver, BC, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>13d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Carnegie-Mellon-University?utm_source=GHList&utm_medium=company">Carnegie Mellon University</a></strong></td>
<td>Cyber AI Engineer Intern</td>
<td>Pittsburgh, PA</td>
<td>Spring 2027</td>
<td>🔒</td>
<td>14d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Ribbon?utm_source=GHList&utm_medium=company">Ribbon</a></strong></td>
<td>AI Engineer Co-op</td>
<td>Westford, MA</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>16d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Altice-USA?utm_source=GHList&utm_medium=company">Altice USA</a></strong></td>
<td>Business Enablement Intern</td>
<td>Long Island City, Queens, NY</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>16d</td>
</tr>
<tr>
<td>↳</td>
<td>Operations Data Analyst Intern</td>
<td>Bethpage, NY</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>16d</td>
</tr>
<tr>
<td>↳</td>
<td>Product Analytics Intern</td>
<td>Bethpage, NY</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>16d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Booz-Allen?utm_source=GHList&utm_medium=company">Booz Allen</a></strong></td>
<td>Data Scientist Intern</td>
<td>McLean, VA</td>
<td>Spring 2027</td>
<td>🔒</td>
<td>17d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/BMO?utm_source=GHList&utm_medium=company">Bank of Montreal</a></strong></td>
<td>Data Analyst Co-op Intern</td>
<td>Toronto, ON, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>17d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Warner-Bros?utm_source=GHList&utm_medium=company">Warner Bros.</a></strong></td>
<td>Data Engineering Co-op</td>
<td>Needham, MA</td>
<td>Spring 2027</td>
<td>🔒</td>
<td>18d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/BlackBerry?utm_source=GHList&utm_medium=company">Blackberry</a></strong></td>
<td>Marketing Data & AI Analyst Intern</td>
<td>Waterloo, ON, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>18d</td>
</tr>
<tr>
<td>🔥 <strong><a href="https://simplify.jobs/c/Amazon?utm_source=GHList&utm_medium=company">Amazon</a></strong></td>
<td>Data Analyst Apprentice</td>
<td>London, UK</td>
<td>Fall 2027</td>
<td>🔒</td>
<td>20d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/University-Of-Ottawa?utm_source=GHList&utm_medium=company">University of Ottawa</a></strong></td>
<td>Research Assistant Intern - Data Analysis</td>
<td>Ottawa, ON, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>21d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Royal-Bank-Of-Canada?utm_source=GHList&utm_medium=company">Royal Bank of Canada</a></strong></td>
<td>Data Analyst Intern - Wealth Management</td>
<td>Toronto, ON, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>21d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/OLG?utm_source=GHList&utm_medium=company">OLG</a></strong></td>
<td>Analytics Engineering & Measurement Student Intern</td>
<td>Toronto, ON, Canada<br>Sault Ste. Marie, ON, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>21d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Medtronic?utm_source=GHList&utm_medium=company">Medtronic</a></strong></td>
<td>Data Quality & Stewardship Apprentice</td>
<td>Watford, UK</td>
<td>Winter 2026</td>
<td>🔒</td>
<td>21d</td>
</tr>
<tr>
<td>↳</td>
<td>Data Quality & Stewardship Apprentice</td>
<td>Watford, UK</td>
<td>Winter 2026</td>
<td>🔒</td>
<td>21d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Ballotpedia?utm_source=GHList&utm_medium=company">Ballotpedia</a></strong></td>
<td>GIS Analyst Intern</td>
<td>Remote in USA</td>
<td>Spring 2027</td>
<td>🔒</td>
<td>21d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Nokia?utm_source=GHList&utm_medium=company">Nokia</a></strong></td>
<td>Wi-Fi Research Co-op 🎓</td>
<td>Sunnyvale, CA</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>22d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Seaspan?utm_source=GHList&utm_medium=company">Seaspan</a></strong></td>
<td>Logistics Support Analysis Intern</td>
<td>North Vancouver, BC, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>23d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Royal-Bank-Of-Canada?utm_source=GHList&utm_medium=company">Royal Bank of Canada</a></strong></td>
<td>Data Analyst Intern</td>
<td>Toronto, ON, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>24d</td>
</tr>
</tbody>
</table>


</details>



## 📈 Quantitative Finance Internship Roles

[Back to top](#summer-2027-tech-internships-by-pitt-csc--simplify)

<table>
<thead>
<tr>
<th>Company</th>
<th>Role</th>
<th>Location</th>
<th>Terms</th>
<th>Application</th>
<th>Age</th>
</tr>
</thead>
<tbody>
<tr>
<td><strong><a href="https://simplify.jobs/c/Alberta-Investment-Management-Corporation?utm_source=GHList&utm_medium=company">Alberta Investment Management Corporation</a></strong></td>
<td>Risk Modelling Co-op 🎓</td>
<td>Calgary, AB, Canada<br>Edmonton, AB, Canada</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://aimco.wd10.myworkdayjobs.com/AIMCoCareers/job/Edmonton/Co-op--Risk-Modelling--Winter-2027-_JR100957?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/08c84138-875e-4818-935f-7922825628a4?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>9d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/JP-Morgan-Chase?utm_source=GHList&utm_medium=company">JP Morgan Chase</a></strong></td>
<td>Quantitative Trading & Research Fellow</td>
<td>London, UK</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://jpmc.fa.oraclecloud.com/hcmUI/CandidateExperience/en/sites/CX_1001/job/210807232?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/77b9974d-4ec7-4763-b2ab-25c2a7abe312?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>10d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Keyrock?utm_source=GHList&utm_medium=company">Keyrock</a></strong></td>
<td>DeFi Quant Trader Intern - Credit</td>
<td>London, UK<br>Brussels, Belgium</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://jobs.ashbyhq.com/keyrock/959a9226-816b-4894-80e6-feaa79018d03/application?embed=true&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/f515d91f-94a1-48f5-b594-661d2e768029?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>11d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Davidson-Kempner?utm_source=GHList&utm_medium=company">Davidson Kempner</a></strong></td>
<td>Quantitative Investment Research Intern</td>
<td>London, UK</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://job-boards.greenhouse.io/5364856uhdfnvbkldfnbhrpkdfgbdvtyhro/jobs/8926928002?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/fe91cc53-5153-42e5-95af-0792a1afc894?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>21d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Keyrock?utm_source=GHList&utm_medium=company">Keyrock</a></strong></td>
<td>DeFi Quant Trader Intern - Credit</td>
<td>London, UK<br>Brussels, Belgium</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://jobs.ashbyhq.com/keyrock/6b46ce15-7e6b-4213-9eb4-41cc64577e24/application?embed=true&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/b069173a-ffd5-4344-b3f1-7efd22920318?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>29d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Keyrock?utm_source=GHList&utm_medium=company">Keyrock</a></strong></td>
<td>DeFi Quant Research Intern - Digital Assets Market Making</td>
<td>London, UK<br>Brussels, Belgium</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://jobs.ashbyhq.com/keyrock/4cae20e0-f315-4ccb-aa8e-df0e87969313/application?embed=true&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/7f6b29de-f117-40a7-b2bc-200fbe3693b9?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>30d</td>
</tr>
<tr>
<td>↳</td>
<td>Quantitative Analyst Intern - Digital Assets Market Making - High-Frequency Trading</td>
<td>London, UK<br>Brussels, Belgium</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://jobs.ashbyhq.com/keyrock/2665c2ed-9131-46d9-9a05-564e7a719d33/application?embed=true&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/477d1468-1490-43aa-b1b9-75910a244997?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>30d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/ExxonMobil?utm_source=GHList&utm_medium=company">ExxonMobil</a></strong></td>
<td>Global Trading Intern - Quantitative Analyst 🎓</td>
<td>London, UK</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://jobs.exxonmobil.com/job/London-Placement-Global-Trading-Quantitative-Analyst-London-2027-LND/1439091600/?ats=successfactors&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/a4ae447e-82f6-4766-8124-560bad4f5c26?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Lendable?utm_source=GHList&utm_medium=company">Lendable</a></strong></td>
<td>Credit Analyst Intern</td>
<td>London, UK</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://jobs.ashbyhq.com/lendable/eabb1e2a-86c3-48e6-836c-af967e0e71d2/application?embed=true&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/edcc3fc0-9e18-4954-b137-6c62c5e479da?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/PanAgora?utm_source=GHList&utm_medium=company">PanAgora</a></strong></td>
<td>Equity Investments Intern</td>
<td>Boston, MA</td>
<td>Winter 2026</td>
<td><div align="center"><a href="https://empower.wd12.myworkdayjobs.com/PanAgora/job/MA-Boston---PanAgora/Intern--Equity-Investments--Winter-2026-2027-_R0062722-1?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/2d95aab9-745c-4250-bdfc-eeba0eae5b63?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Cboe?utm_source=GHList&utm_medium=company">Cboe</a></strong></td>
<td>Quant & Data Analytics Intern 🎓</td>
<td>Chicago, IL</td>
<td>Winter 2026</td>
<td><div align="center"><a href="https://cboe.wd1.myworkdayjobs.com/External_Career_CBOE/job/Chicago-IL/Quant---Data-Analytics-Intern_R-4708?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/82983d30-e0d9-4a6c-b404-3761e8773222?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>1mo</td>
</tr>
</tbody>
</table>


<details>
<summary>🗃️ Inactive roles (118)</summary>

<table>
<thead>
<tr>
<th>Company</th>
<th>Role</th>
<th>Location</th>
<th>Terms</th>
<th>Application</th>
<th>Age</th>
</tr>
</thead>
<tbody>
<tr>
<td><strong><a href="https://simplify.jobs/c/Royal-Bank-Of-Canada?utm_source=GHList&utm_medium=company">Royal Bank of Canada</a></strong></td>
<td>Model Risk Intern</td>
<td>Toronto, ON, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>29d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/CIBC?utm_source=GHList&utm_medium=company">CIBC</a></strong></td>
<td>Analyst Co-op</td>
<td>Montreal, QC, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>29d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/TMX-Group?utm_source=GHList&utm_medium=company">TMX Group</a></strong></td>
<td>Analyst Model Validation Intern</td>
<td>Montreal, QC, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Royal-Bank-Of-Canada?utm_source=GHList&utm_medium=company">Royal Bank of Canada</a></strong></td>
<td>AI & Stress Testing Analytics Intern</td>
<td>Toronto, ON, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/AON?utm_source=GHList&utm_medium=company">Aon</a></strong></td>
<td>Actuarial Intern - Client Consulting</td>
<td>Toronto, ON, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Royal-Bank-Of-Canada?utm_source=GHList&utm_medium=company">Royal Bank of Canada</a></strong></td>
<td>Retail Risk Modeling Analyst Intern</td>
<td>Toronto, ON, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Deloitte?utm_source=GHList&utm_medium=company">Deloitte</a></strong></td>
<td>Audit & Assurance Intern - Valuation & Analytics</td>
<td>Atlanta, GA</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Athene?utm_source=GHList&utm_medium=company">Athene</a></strong></td>
<td>Risk Co-op</td>
<td>West Des Moines, IA</td>
<td>Winter 2026</td>
<td>🔒</td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/NJ-Department-Of-Environmental-Protection?utm_source=GHList&utm_medium=company">NJ Department of Environmental Protection</a></strong></td>
<td>Economic Analysis Intern</td>
<td>Trenton, NJ</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Royal-Bank-Of-Canada?utm_source=GHList&utm_medium=company">Royal Bank of Canada</a></strong></td>
<td>Credit Modeling and Methodology Analyst Intern - GRM</td>
<td>Toronto, ON, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/DRW?utm_source=GHList&utm_medium=company">DRW</a></strong></td>
<td>Quantitative Trading Analyst Intern</td>
<td>Chicago, IL</td>
<td>Winter 2026</td>
<td>🔒</td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Old-Mission?utm_source=GHList&utm_medium=company">Old Mission</a></strong></td>
<td>Quantitative Trader Intern</td>
<td>Chicago, IL</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/PNC-Financial-Services?utm_source=GHList&utm_medium=company">PNC Financial Services</a></strong></td>
<td>Economics Intern - Multiple Teams 🎓</td>
<td>NYC</td>
<td>Winter 2026</td>
<td>🔒</td>
<td>1mo</td>
</tr>
<tr>
<td>↳</td>
<td>Modeling Graduate Intern - Modeling - Chief Investment Office 🎓</td>
<td>NYC</td>
<td>Winter 2026</td>
<td>🔒</td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Manulife-Financial?utm_source=GHList&utm_medium=company">Manulife Financial</a></strong></td>
<td>ALM Data Management & Analytics Co-op</td>
<td>Toronto, ON, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Voloridge?utm_source=GHList&utm_medium=company">Voloridge</a></strong></td>
<td>Quantitative Trading Intern</td>
<td>Jupiter, FL</td>
<td>Winter 2026</td>
<td>🔒</td>
<td>2mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Royal-Bank-Of-Canada?utm_source=GHList&utm_medium=company">Royal Bank of Canada</a></strong></td>
<td>Quantum Technologies Intern</td>
<td>Toronto, ON, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>2mo</td>
</tr>
<tr>
<td>↳</td>
<td>Quantum Technologies Intern - 8 Months</td>
<td>Toronto, ON, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>2mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Citadel?utm_source=GHList&utm_medium=company">Citadel</a></strong></td>
<td>Fixed Income & Macro Trader Intern - US</td>
<td>Greenwich, CT<br>Miami, FL<br>NYC</td>
<td>Winter 2026</td>
<td>🔒</td>
<td>2mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Hudson-River-Trading?utm_source=GHList&utm_medium=company">Hudson River Trading</a></strong></td>
<td>PhD Winter Intern 🎓</td>
<td>NYC</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>2mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/The-Voleon-Group?utm_source=GHList&utm_medium=company">The Voleon Group</a></strong></td>
<td>Research Intern 🎓</td>
<td>London, UK</td>
<td>Winter 2026</td>
<td>🔒</td>
<td>2mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Wellington-Management?utm_source=GHList&utm_medium=company">Wellington Management</a></strong></td>
<td>Global Risk & Performance Strategy Co-op - Multi-Asset and Hedge Fund Risk - Fixed Income Risk</td>
<td>Boston, MA</td>
<td>Winter 2026, Winter 2027</td>
<td>🔒</td>
<td>2mo</td>
</tr>
<tr>
<td>↳</td>
<td>Quantitative Trading Co-op</td>
<td>Boston, MA</td>
<td>Winter 2026</td>
<td>🔒</td>
<td>2mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Equitable-Bank?utm_source=GHList&utm_medium=company">Equitable Bank</a></strong></td>
<td>Credit Risk Intern</td>
<td>Toronto, ON, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>2mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/PanAgora?utm_source=GHList&utm_medium=company">PanAgora</a></strong></td>
<td>Equity Intern</td>
<td>Boston, MA</td>
<td>Winter 2026</td>
<td>🔒</td>
<td>2mo</td>
</tr>
</tbody>
</table>


</details>



## 🔧 Hardware Engineering Internship Roles

[Back to top](#summer-2027-tech-internships-by-pitt-csc--simplify)

<table>
<thead>
<tr>
<th>Company</th>
<th>Role</th>
<th>Location</th>
<th>Terms</th>
<th>Application</th>
<th>Age</th>
</tr>
</thead>
<tbody>
<tr>
<td><strong><a href="https://simplify.jobs/c/X-Development?utm_source=GHList&utm_medium=company">X Development</a></strong></td>
<td>PhD / Master's Resident - Revolutionary Nanodevice Measurement and Characterization - Early Stage Project 🎓</td>
<td>Mountain View, CA</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://x.company/careers/8472640002?gh_jid=8472640002&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/ea676687-2aed-4508-ba3d-fc66f2c21586?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>1d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Advanced-Energy?utm_source=GHList&utm_medium=company">Advanced Energy</a></strong></td>
<td>Firmware Engineer Intern</td>
<td>Fort Collins, CO</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://jobs.advanced-energy.com/job/Fort-Collins-Intern-Firmware-Engineer-Spring-2027-CO-80525/1453648400/?ats=successfactors&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/13cb67a5-c287-4ef1-a6ec-ff256d6c3e0b?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>2d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Ralliant?utm_source=GHList&utm_medium=company">Ralliant</a></strong></td>
<td>Hardware Engineering Co-op</td>
<td>Solon, OH</td>
<td>Spring 2026</td>
<td><div align="center"><a href="https://ibwujb.fa.ocs.oraclecloud.com/hcmUI/CandidateExperience/en/sites/CX_1001/job/10451?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/fe9170a7-7096-4d38-9845-9cf5b534d862?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>2d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Neuralink?utm_source=GHList&utm_medium=company">Neuralink</a></strong></td>
<td>Electrical Test Engineer Intern</td>
<td>South SF</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://boards.greenhouse.io/neuralink/jobs/8197808003?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/3269a8e7-99ce-41bb-bffb-4015d4310f95?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>2d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Paccar?utm_source=GHList&utm_medium=company">Paccar</a></strong></td>
<td>Vehicle Software Integration Engineer Intern</td>
<td>Denton, TX<br>Sunnyvale, CA</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://jobs.paccar.com/job/Sunnyvale-2027-Spring-Internship-Vehicle-Software-Integration-Engineer-CA-94089/1459888133/?ats=successfactors&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/3c63e1b8-3433-4cb8-9a82-bbda924ef085?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>3d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Seasats?utm_source=GHList&utm_medium=company">Seasats</a></strong></td>
<td>Electronics Engineering Intern</td>
<td>San Diego, CA</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://seasats.breezy.hr/p/58eb0549bc6d/apply?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/3c53fcff-20c6-413f-a5dc-2c5080cdf728?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>3d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Nottingham-Spirk?utm_source=GHList&utm_medium=company">Nottingham Spirk</a></strong></td>
<td>Firmware Co-op</td>
<td>Cleveland, OH</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://nottinghamspirk.applytojob.com/apply/udpROpEzBV/Firmware-Spring-2027-CoOp?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/54b604ed-cdf0-4d1b-b9cf-d01b687dcd49?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>5d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/MDA-Space?utm_source=GHList&utm_medium=company">MDA Space</a></strong></td>
<td>Engineering Student Intern - FPGA</td>
<td>Sainte-Anne-de-Bellevue, QC, Canada</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://recruiting.ultipro.ca/MAC5000MCDW/JobBoard/664818ff-3594-4bec-9f30-3394e59e19f3/OpportunityDetail?opportunityId=216d347b-2abb-43e8-8fbc-268adecf0aa3&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/df93e0b7-e4cd-4c32-95f0-5a2b51470459?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>6d</td>
</tr>
<tr>
<td>↳</td>
<td>Engineering Student Intern - FPGA Verification</td>
<td>Sainte-Anne-de-Bellevue, QC, Canada</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://recruiting.ultipro.ca/MAC5000MCDW/JobBoard/664818ff-3594-4bec-9f30-3394e59e19f3/OpportunityDetail?opportunityId=e40bbead-0940-4adb-9ae8-2b3d4d3d6874&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/d466dadc-081f-464e-8b67-6c243491f5f1?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>6d</td>
</tr>
<tr>
<td>↳</td>
<td>Engineering Student Intern - Digital Electronics Test Station Design</td>
<td>Sainte-Anne-de-Bellevue, QC, Canada</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://recruiting.ultipro.ca/MAC5000MCDW/JobBoard/664818ff-3594-4bec-9f30-3394e59e19f3/OpportunityDetail?opportunityId=080ac9a6-c9f4-4d51-bcf6-b4085e35e941&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/82abb644-c4fa-43ef-b105-70755067d781?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>6d</td>
</tr>
<tr>
<td>↳</td>
<td>Engineering Intern - Test Procedure Engineering</td>
<td>Sainte-Anne-de-Bellevue, QC, Canada</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://recruiting.ultipro.ca/MAC5000MCDW/JobBoard/664818ff-3594-4bec-9f30-3394e59e19f3/OpportunityDetail?opportunityId=23ba7a5c-469f-40f6-b33c-6e7bcbcf5355&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/696bd912-c838-42ee-8341-855650d639ee?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>6d</td>
</tr>
<tr>
<td>↳</td>
<td>Engineering Student Intern - PCB Design and Electronic Integration</td>
<td>Sainte-Anne-de-Bellevue, QC, Canada</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://recruiting.ultipro.ca/MAC5000MCDW/JobBoard/664818ff-3594-4bec-9f30-3394e59e19f3/OpportunityDetail?opportunityId=72d36cf7-637b-4e91-a9d6-660f11cb8075&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/5b561e45-7265-42fb-93ad-090440f9820b?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>6d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/SIG-SAUER?utm_source=GHList&utm_medium=company">SIG SAUER</a></strong></td>
<td>Electrical Engineer Intern</td>
<td>Exeter, NH</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://recruiting.ultipro.com/sig1011sigsa/JobBoard/9ec422f8-2ba7-4e60-983b-b473bf030bd6/OpportunityDetail?opportunityId=17fa465e-b4ef-4e7e-bbcb-d55fe5bddb1e&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/3a6c3acd-6adc-4247-921d-1542972ff15f?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>6d</td>
</tr>
<tr>
<td>↳</td>
<td>Electrical/Computer Engineering Intern - Uncrewed Systems</td>
<td>Sanford, NC</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://recruiting.ultipro.com/sig1011sigsa/JobBoard/9ec422f8-2ba7-4e60-983b-b473bf030bd6/OpportunityDetail?opportunityId=3af1fb9e-2e3d-4fd9-89f0-d2b9bc090053&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/037c3293-1211-4287-b8b8-9886583b4674?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>6d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Avnan?utm_source=GHList&utm_medium=company">Avnan</a></strong></td>
<td>Electronics Engineering Technologist Co-op</td>
<td>Mississauga, ON, Canada</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://avnan.bamboohr.com/careers/125/?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/eec7def1-2dd9-4afc-b912-c52ea1034c4c?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>6d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Samsung-Research-America?utm_source=GHList&utm_medium=company">Samsung Research America</a></strong></td>
<td>Memory Subsystem Intern - SoC Architecture 🎓</td>
<td>Mountain View, CA</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://job-boards.greenhouse.io/samsungresearchamericainternship/jobs/8949357002?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/133dfd58-e65d-4b80-951a-bd1a9a54546e?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>7d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Western-Digital?utm_source=GHList&utm_medium=company">Western Digital</a></strong></td>
<td>Software Engineering Intern</td>
<td>Irvine, CA</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://jobs.smartrecruiters.com/WesternDigital/744000162353069?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/0590c67b-538d-436a-97a1-2344effdb7cb?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>8d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Bose?utm_source=GHList&utm_medium=company">Bose</a></strong></td>
<td>Software Engineer Co-op</td>
<td>Framingham, MA</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://boseallaboutme.wd503.myworkdayjobs.com/Bose_Careers/job/US-MA---Framingham/Software-Engineer-Co-op_R29387?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/aadac344-466b-49c1-9edf-8e0bbb15a85d?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>9d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Rivian?utm_source=GHList&utm_medium=company">Rivian</a></strong></td>
<td>ADAS HW Systems Validation Intern - ADAS HW Systems Validation</td>
<td>Champaign, IL</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://careers.rivian.com/jobs/36514?icims=1&lang=en-us&utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/cfef62f9-0ea8-4070-b549-5bba93413913?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>9d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Ralliant?utm_source=GHList&utm_medium=company">Ralliant</a></strong></td>
<td>Hardware Verification Engineer Co-op</td>
<td>Solon, OH</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://ibwujb.fa.ocs.oraclecloud.com/hcmUI/CandidateExperience/en/sites/CX_1001/job/10490?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/727e38b8-6d35-4125-a4de-e549c42874ec?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>10d</td>
</tr>
<tr>
<td>🔥 <strong><a href="https://simplify.jobs/c/Tesla?utm_source=GHList&utm_medium=company">Tesla</a></strong></td>
<td>Electrical Engineer Intern - High Speed Hardware Design</td>
<td>Palo Alto, CA</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://www.tesla.com/careers/search/job/289951?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/c1425ae2-392c-49bf-85ed-ed6b1a855c66?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>12d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/North-Atlantic-Industries?utm_source=GHList&utm_medium=company">North Atlantic Industries</a></strong></td>
<td>Embedded Software Engineer Intern</td>
<td>Bohemia, NY</td>
<td>Spring 2027</td>
<td><div align="center"><a href="https://recruiting.paylocity.com/Recruiting/Jobs/Details/4663112?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/2b94607b-1a38-495e-a48c-3a753cda40d5?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>14d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/SK-Hynix?utm_source=GHList&utm_medium=company">SK hynix</a></strong></td>
<td>Embedded Software Engineer Intern</td>
<td>San Jose, CA</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://job-boards.greenhouse.io/skhynixmemorysolutionsamericainc/jobs/4504499009?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/90f83c10-7dfd-4e63-a95c-5a362f8e27a7?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>15d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Ciena?utm_source=GHList&utm_medium=company">Ciena</a></strong></td>
<td>Layout Design Co-op</td>
<td>Ottawa, ON, Canada</td>
<td>Winter 2027</td>
<td><div align="center"><a href="https://ciena.wd5.myworkdayjobs.com/Careers/job/Ottawa/Layout-Design-Co-op--Winter-2027-_R032103?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/099ef7b6-a38d-4765-8a08-01ca372fb0e3?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>16d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Bose?utm_source=GHList&utm_medium=company">Bose</a></strong></td>
<td>Digital Signal Processing Machine Learning Software Development Co-op</td>
<td>Framingham, MA</td>
<td>Fall 2026</td>
<td><div align="center"><a href="https://boseallaboutme.wd503.myworkdayjobs.com/Bose_Careers/job/US-MA---Framingham/Digital-Signal-Processing-ML-Software-Development-Co-op_R29372?utm_source=Simplify&ref=Simplify"><img src="https://i.imgur.com/fbjwDvo.png" width="50" alt="Apply"></a> <a href="https://simplify.jobs/p/c6cfbcd7-5b84-4498-baed-bc3ba3014ecb?utm_source=GHList"><img src="https://i.imgur.com/aVnQdox.png" width="26" alt="Simplify"></a></div></td>
<td>16d</td>
</tr>
</tbody>
</table>


<details>
<summary>🗃️ Inactive roles (1093)</summary>

<table>
<thead>
<tr>
<th>Company</th>
<th>Role</th>
<th>Location</th>
<th>Terms</th>
<th>Application</th>
<th>Age</th>
</tr>
</thead>
<tbody>
<tr>
<td><strong><a href="https://simplify.jobs/c/MDA-Space?utm_source=GHList&utm_medium=company">MDA Space</a></strong></td>
<td>Engineering Intern - Test Procedures Engineering</td>
<td>Sainte-Anne-de-Bellevue, QC, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>6d</td>
</tr>
<tr>
<td>🔥 <strong><a href="https://simplify.jobs/c/AMD?utm_source=GHList&utm_medium=company">AMD</a></strong></td>
<td>Masters Server Power Management Engineering Co-op 🎓</td>
<td>Austin, TX</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>6d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/AON3D?utm_source=GHList&utm_medium=company">AON3D</a></strong></td>
<td>Software Developer Intern</td>
<td>Montreal, QC, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>6d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Sumitomo-Electric-Wiring-Systems?utm_source=GHList&utm_medium=company">Sumitomo Electric Wiring Systems</a></strong></td>
<td>Validation Engineer Co-op Intern</td>
<td>Farmington Hills, MI</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>15d</td>
</tr>
<tr>
<td>🔥 <strong><a href="https://simplify.jobs/c/NVIDIA?utm_source=GHList&utm_medium=company">NVIDIA</a></strong></td>
<td>Performance Engineering Intern - Platform Performance and Power</td>
<td>Canada<br>Santa Clara, CA<br>United States</td>
<td>Spring 2027</td>
<td>🔒</td>
<td>17d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Applied-Materials?utm_source=GHList&utm_medium=company">Applied Materials</a></strong></td>
<td>Software Engineer Co-op</td>
<td>Billerica, MA</td>
<td>Spring 2027</td>
<td>🔒</td>
<td>17d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/RTX?utm_source=GHList&utm_medium=company">RTX</a></strong></td>
<td>Digital Hardware Design Engineer Co-op</td>
<td>Cedar Rapids, IA</td>
<td>Winter 2027, Spring 2027</td>
<td>🔒</td>
<td>18d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/DwyerOmega?utm_source=GHList&utm_medium=company">DwyerOmega</a></strong></td>
<td>Electrical Engineer Intern</td>
<td>Westerville, OH</td>
<td>Spring 2027</td>
<td>🔒</td>
<td>22d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Northrop-Grumman?utm_source=GHList&utm_medium=company">Northrop Grumman</a></strong></td>
<td>Software Engineer Co-op Intern</td>
<td>McClellan Park, CA</td>
<td>Spring 2027</td>
<td>🔒</td>
<td>23d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Pacific-Northwest-National-Laboratory?utm_source=GHList&utm_medium=company">Pacific Northwest National Laboratory</a></strong></td>
<td>Undergraduate Tech Intern - Electrical Engineering</td>
<td>Richland, WA</td>
<td>Winter 2026</td>
<td>🔒</td>
<td>23d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Wabtec?utm_source=GHList&utm_medium=company">Wabtec</a></strong></td>
<td>Firmware Engineering Co-op</td>
<td>Waltham, MA</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>23d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Renesas-Electronics?utm_source=GHList&utm_medium=company">Renesas Electronics</a></strong></td>
<td>Product Engineer Intern</td>
<td>Morrisville, NC</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>24d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Toshiba-Global-Commerce?utm_source=GHList&utm_medium=company">Toshiba Global Commerce Solutions</a></strong></td>
<td>Software Engineer Intern</td>
<td>Durham, NC</td>
<td>Spring 2027</td>
<td>🔒</td>
<td>24d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Nokia?utm_source=GHList&utm_medium=company">Nokia</a></strong></td>
<td>Silicon Photonics Packaging Engineer Co-op 🎓</td>
<td>Sunnyvale, CA</td>
<td>Spring 2027</td>
<td>🔒</td>
<td>27d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Keysight-Technologies-Inc?utm_source=GHList&utm_medium=company">Keysight Technologies</a></strong></td>
<td>FPGA Design Intern</td>
<td>Calabasas, CA</td>
<td>Fall 2027</td>
<td>🔒</td>
<td>27d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/RTX?utm_source=GHList&utm_medium=company">RTX</a></strong></td>
<td>Electrical Engineer Co-op - Winter/Spring 2027</td>
<td>Cedar Rapids, IA</td>
<td>Winter 2027, Spring 2027</td>
<td>🔒</td>
<td>28d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/SmartFlower-Solar?utm_source=GHList&utm_medium=company">SmartFlower Solar</a></strong></td>
<td>Embedded Systems Engineering Intern</td>
<td>Woburn, MA</td>
<td>Winter 2026, Spring 2026</td>
<td>🔒</td>
<td>28d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/LunarEnergy?utm_source=GHList&utm_medium=company">Lunar Energy</a></strong></td>
<td>Hardware Test Engineer Intern</td>
<td>Mountain View, CA</td>
<td>Spring 2027</td>
<td>🔒</td>
<td>28d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Hasbro?utm_source=GHList&utm_medium=company">Hasbro</a></strong></td>
<td>Electrical Engineering Co-op</td>
<td>Boston, MA</td>
<td>Spring 2027</td>
<td>🔒</td>
<td>28d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Johnson-Controls?utm_source=GHList&utm_medium=company">Johnson Controls</a></strong></td>
<td>Software Engineering Co-op</td>
<td>Burlington, MA</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>30d</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Hitachi?utm_source=GHList&utm_medium=company">Hitachi</a></strong></td>
<td>Software Analyst Intern</td>
<td>Toronto, ON, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Ciena?utm_source=GHList&utm_medium=company">Ciena</a></strong></td>
<td>Optical Performance Lab Verification and Testing Co-op</td>
<td>Ottawa, ON, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>1mo</td>
</tr>
<tr>
<td>↳</td>
<td>Electronic Reliability Engineer Co-op</td>
<td>Ottawa, ON, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Videotron?utm_source=GHList&utm_medium=company">Videotron</a></strong></td>
<td>Engineering Intern</td>
<td>Montreal, QC, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>1mo</td>
</tr>
<tr>
<td><strong><a href="https://simplify.jobs/c/Marvell?utm_source=GHList&utm_medium=company">Marvell</a></strong></td>
<td>Design Verification Intern</td>
<td>Toronto, ON, Canada</td>
<td>Winter 2027</td>
<td>🔒</td>
<td>1mo</td>
</tr>
</tbody>
</table>


</details>

